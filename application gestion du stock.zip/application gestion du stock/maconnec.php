<?php 
mysql_connect('localhost','root','') or die('erreur');
mysql_select_db('memoire') or die ('erreur1');
?>