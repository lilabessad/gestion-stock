<?php include('connection.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>singature d'une dai</title>
<script type="text/javascript">
//<![CDATA[

function valider(){
 
 if(document.form1.numd.value == "") {
   alert("Veuillez entrer le numéro de D.A.I!");
   document.form1.numd.focus();
   return false;
  }
  else alert("la D.A.I a bien été signée");}
</script>

<style type="text/css">
<!--
.Style1 {	color: #FFDF00;
	font-weight: bold;
	font-style: italic;
}
.Style6 {	color: #FF1F00;
	font-style: italic;
	font-weight: bold;
}
.Style19 {color: #0000FF; font-weight: bold; font-style: italic; font-size: 18px; }
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="" onsubmit="return valider();">
  <table width="1271" height="378" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1264" height="354"><table width="1259" height="436" border="0" align="center">
        <tr>
          <td height="53" colspan="4" bgcolor="#0000FF"><div align="center">
            <h1><span class="Style1">SIGNATURE DE D.A.I:</span></h1>
          </div></td>
        </tr>
        <tr>
          <td height="67" colspan="4"><div align="center">
            <h2 align="left" class="Style6">Veuillez saisir le numéro de la D.A.I que vous voulez signer:</h2>
          </div></td>
        </tr>
        <tr>
          <td width="287" height="59"><div align="center">
            <h2><strong><em>Numéro de la D.A.I:</em></strong></h2>
          </div></td>
          <td width="229"><input type="text" name="numd" id="mn" /></td>
          <td colspan="2"><label>
            <input type="submit" name="ok" id="ok" value="   OK  " />
          </label></td>
        </tr>
        <tr>
          <td height="22" colspan="4"><div align="center">
            <h2 align="left" class="Style6">Vérifier les informations suivantes :</h2>
          </div></td>
        </tr>
        <tr>
          <td height="22" colspan="2"><div align="center">
            <h2><em><strong>Origine de la D.A.I:</strong></em></h2>
          </div></td>
          <td height="22" colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td height="22" colspan="2"><div align="center">
            <h2><strong><em>Date d'emission:</em></strong></h2>
          </div></td>
          <td height="22" colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td height="43" colspan="2"><div align="center">
            <h2><strong><em>Statut d'achat:</em></strong></h2>
          </div></td>
          <td height="43" colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td height="47" colspan="2" rowspan="2" valign="top"><div align="center">
            <h2><strong><em>Objet de la D.A.I:</em></strong></h2>
          </div></td>
          <td height="39" colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td width="544" height="32"><div align="right">
            <input name="ok2" type="submit" class="Style19" id="ok2" value=" signer " />
          </div></td>
          <td width="181"><div align="right" id="an">
            <div align="center">
              <input name="button" type="reset" class="Style19" id="button" value="Annuler" />
            </div>
          </div></td>
        </tr>
      </table>      
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
<script type="text/javascript">
//<![CDATA[

function assure(){
  // si la valeur de la dai ni pas saisir
  if(document.form1.numd.value !="" )
        {
		alert("la D.A.I a été bien signée");
    // le numero existe, on peut envoyer le formulaire    
    return true;
 }
  else {
    // sinon on affiche un message
    alert("Veuillez saisir le numero de votre D.A.I");
    // et on indique de ne pas envoyer le formulaire
    return false;
  }
  
}

//]]>
</script>
</body>
</html>
<script type="text/javascript">
<?php

$num=$_POST['numd'];
$sql="UPDATE dai SET signature ='signée' WHERE numdai = '$num'";
$rep=mysql_query($sql);
IF (!$rep) {
   die('Requête invalide : ' . mysql_error());
}
?></script>