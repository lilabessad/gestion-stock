<?php 
session_start();include('maconnec.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans nom</title>
<script type="text/javascript">
//<![CDATA[

function valider(){
  // si la valeur du champ prenom est non vide
  if(document.form1.art.value !="") {
    // les donn�es sont ok, on peut envoyer le formulaire    
    return true;
  }
  else {
    // sinon on affiche un message
    alert("veuillez saisir le num�ro de l'article que vous voulez consulter");
    // et on indique de ne pas envoyer le formulaire
	   document.form1.art.focus();
    return false;
  }
  
}
</script>
<style type="text/css">
<!--
.Style1 {	font-size: 36px;
	color: #FF0000;
}
.Style2 {font-size: 18px}
.Style3 {font-size: 18px; color: #0000FF; }
-->
</style>
</head>

<body>
<?php
if (isset($_POST['valid'])){
$co = $_POST['codearticle'];
$res = mysql_query("select * from  article where code_art = ".$co);
}
?>
<form id="form1" name="form1" method="post" action="mou.php"  onsubmit=" return valider(); ">
  <table width="1013" height="572" border="6" bordercolor="#FFCC00" align="center">
    <tr>
      <td width="993" height="556"><table width="982" height="552" border="0" >
        <tr>
          <td height="45" colspan="2" bgcolor="#FFFFCC"><div align="center" class="Style1">Mouvement de r&eacute;ception </div></td>
        </tr>
        <tr>
          <td width="676"><div align="left" class="Style3">Saisissez le code d'article pour le quel vous voulez fair le mouvement </div></td>
          <td width="307">Code article
            <label>
            <input name="codearticle" type="text" id="codearticle" />
            </label>
            <label>
            <input name="valid" type="submit" id="valid" value="Valider" />
			
            </label>
           	</td>
        </tr>
        <tr>
          <td height="23" colspan="2"><span class="Style3 Style2">Veuillez completer les champs: </span></td>
        </tr>
        <tr>
          <td colspan="2"><table width="987" height="56" border="2">
            <tr>
              <td width="162"><div align="center">Code article </div></td>
              <td width="154"><div align="center">D&eacute;signation </div></td>
              <td width="210"><div align="center">Unit&eacute; de m&eacute;sure  </div></td>
              <td width="230"><div align="center">Quantit&eacute; manquante</div></td>
              <td width="195">Quantit&eacute; en plus</td>
            </tr>
					<?php 
       if(isset($_POST['valid'])){
			?>
			 <?php
  while($data=mysql_fetch_array ($res))
  {
  ?>
            <tr>
              <td height="23"><?php echo $data['code_art']; ?></td>
              <td><?php echo $data['des_art']; ?></td>
              <td><?php echo $data['unit_mesur']; ?></td>
			  
              <td align="center"><label> </label>
                  <label>
                  <input name="Quantit&eacute; manquante" type="text" id="Quantit&eacute; manquante" />
                  </label>
                  <div align="left"></div></td>
              <td align="center"><input name="qtitplus" type="text" id="qtitplus" /></td>
            </tr>
			 <?php } ?>
			  <?php } ?>
          </table></td>
        </tr>
        <tr>
          <td height="45"><table width="676" border="0">
              <tr>
                <td width="177" height="24">Nature du mouvement
                  <label></label></td>
                <td width="489"><input name="Nature du mouvement" type="text" id="Nature du mouvement" /></td>
              </tr>
            </table>
              <label></label></td>
          <td rowspan="5"><a href="mouvrecen.php">Afficher un mouvement r&eacute;cent </a></td>
        </tr>
        <tr>
          <td height="51"><table width="671" border="0">
              <tr>
                <td width="175" height="24">Num&eacute;ro livraison
                  <label></label></td>
                <td width="486"><input name="Num&eacute;ro livraison" type="text" id="Num&eacute;ro livraison" /></td>
              </tr>
            </table>
              <label></label></td>
          </tr>
        <tr>
          <td><table width="671" border="0">
            <tr>
              <td width="174" height="24">Date de mouvement
                <label></label></td>
              <td width="487"><input name="Date de mouvement" type="text" id="Date de mouvement" /></td>
            </tr>
          </table></td>
          </tr>
        <tr>
          <td><table width="669" border="0">
            <tr>
              <td width="174" height="24">Service &eacute;metteur
                <label></label></td>
              <td width="485"><input name="Service &eacute;metteur" type="text" id="Service &eacute;metteur" /></td>
            </tr>
          </table></td>
          </tr>
        <tr>
          <td><table width="664" border="0">
            <tr>
              <td width="174" height="24">Num&eacute;ro de mouvement
                <label></label></td>
              <td width="480"><input name="Num&eacute;ro de mouvement" type="text" id="Num&eacute;ro de mouvement" /></td>
            </tr>
          </table></td>
          </tr>
        <tr>
          <td height="26" colspan="2"><div align="center">
            <label>
            <input type="submit" name="Submit" value="Valider" />
            </label>
          </div></td>
        </tr>
        
      </table></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
