<?php include('maconnec.php'); 
$na=$_POST['natmov'];
$nu=$_POST['numliv'];
$d=$_POST['datmov'];
$s=$_POST['servemet'];
$num=$_POST['nummov'];
$sql='insert into mouvmenrecep (nat_mv, num_liv, dat_mv, ser_emt, num_mv) values("'.$na.'","'.$nu.'","'.$d.'","'.$s.'","'.$num.'")';
mysql_query($sql);
?>

