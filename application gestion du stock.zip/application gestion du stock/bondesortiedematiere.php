<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans nom</title>
<style type="text/css">
<!--
.Style1 {
	font-size: 24px;
	font-weight: bold;
}
.Style2 {font-size: 24px}
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="1056" height="861" border="2" align="center">
    <tr>
      <td width="1044" height="853"><table width="1061" height="813" border="2">
        <tr>
          <td height="144" colspan="2"><div align="center">
            <p class="Style1">ENIEM</p>
            <p align="left">Unit&eacute;:
              <label>
              <input type="text" name="textfield" />
              </label>
            </p>
            <p align="left">Structure
              <label>
              <input type="text" name="textfield2" />
              </label>
            </p>
            <p align="left">C.F:
              <label>
              <input type="text" name="textfield3" />
              </label>
            </p>
          </div></td>
          <td colspan="2"><div align="center" class="Style2">BON DE SORTIE MATIERE </div></td>
          <td width="310"><p>Document n&deg;:
              <label>
              <input type="text" name="textfield5" />
              </label>
          </p>
            <p>Etabli le:
			<select name="jour" id="jumpMenu" onchange="">
                    <option>jour</option>
                    <option>01</option>
                    <option>02</option>
                    <option>03</option>
                    <option>04</option>
                    <option>05</option>
                    <option>06</option>
                    <option>07</option>
                    <option>08</option>
                    <option>09</option>
                    <option>10</option>
                    <option>11</option>
                    <option>12</option>
                    <option>13</option>
                    <option>14</option>
                    <option>15</option>
                    <option>16</option>
                    <option>17</option>
                    <option>18</option>
                    <option>19</option>
                    <option>20</option>
                    <option>21</option>
                    <option>22</option>
                    <option>23</option>
                    <option>24</option>
                    <option>25</option>
                    <option>26</option>
                    <option>27</option>
                    <option>28</option>
                    <option>29</option>
                    <option>30</option>
                    <option>31</option>
                </select>
                  <select name="mois" id="jumpMenu2" onchange="">
                    <option>Mois</option>
                    <option>Janvier</option>
                    <option>Fevrier</option>
                    <option>Mars</option>
                    <option>Avril</option>
                    <option>Mai</option>
                    <option>Juin</option>
                    <option>Juillet</option>
                    <option>Aout</option>
                    <option>Septembre</option>
                    <option>Octobre</option>
                    <option>Novembre</option>
                    <option>Decembre</option>
                  </select>
                  <select name="anne" id="jumpMenu3" onchange="">
                    <option>Ann&eacute;e</option>
                    <option>2000</option>
                    <option>2001</option>
                    <option>2002</option>
                    <option>2003</option>
                    <option>2004</option>
                    <option>2005</option>
                    <option>2006</option>
                    <option>2007</option>
                    <option>2008</option>
                    <option>2009</option>
                    <option>2010</option>
                    <option>2011</option>
                    <option>2012</option>
                    <option>2013</option>
                    <option>2014</option>
                    <option>2015</option>
                    <option>2016</option>
                    <option>2017</option>
                    <option>2018</option>
                    <option>2019</option>
                    <option>2020</option>
                  </select>
			</p>
            <p>Par........................Eq. ....................</p>
            <p>Fonction................ Visa .................</p></td>
        </tr>
        <tr>
          <td colspan="2" rowspan="2">Origine : 
            <label>
            <input type="text" name="textfield4" />
            </label></td>
          <td colspan="2"><div align="center">Utilisation</div></td>
          <td rowspan="2"><div align="center">Imputation analytique </div></td>
        </tr>
        <tr>
          <td width="204">C F ex&eacute;cutif....................... </td>
          <td width="237">C F d&eacute;bit&eacute;................................ </td>
        </tr>
        <tr>
          <td height="116" colspan="5"><table width="1049" height="259" border="1">
            <tr>
              <td width="78" rowspan="2"><div align="center">N&deg;</div></td>
              <td height="23" colspan="2"><div align="center">Marchandise</div></td>
              <td width="104" rowspan="2"><div align="center">Unit&eacute;</div></td>
              <td colspan="2"><div align="center">Quantit&eacute;</div></td>
              <td width="98" rowspan="2"><div align="center">Prix unitaire </div></td>
              <td width="166" rowspan="2"><div align="center">Montant</div></td>
            </tr>
            <tr>
              <td width="103" height="23"><div align="center">Code</div></td>
              <td width="239"><div align="center">D&eacute;signation</div></td>
              <td width="105"><div align="center">Demand&eacute;</div></td>
              <td width="104"><div align="center">Livr&eacute;e</div></td>
              </tr>
            <tr>
              <td height="26"><label>
                <input type="text" name="textfield6" width="70" />
              </label></td>
              <td><input type="text" name="textfield68" width="95" /></td>
              <td><p>.
                <input type="text" name="textfield7"  width="230"/>
                <label></label>
              </p>                  </td>
              <td><p>.
                <input type="text" name="textfield688" width="95" />
              </p>                  </td>
              <td><p>
                <input type="text" name="textfield6815" width="95" />
              </p>                  </td>
              <td><p>.
                <input type="text" name="textfield6822" width="95" />
              </p>                  </td>
              <td><p>
                <input type="text" name="textfield6829" width="95" />
              </p>                  </td>
              <td><p>
                <input type="text" name="textfield6836" width="180" />
              </p>                  </td>
            </tr>
            <tr>
              <td height="29"><input type="text" name="textfield62" width="70" /></td>
              <td><input type="text" name="textfield682" width="95" /></td>
              <td><input type="text" name="textfield72"  width="230"/></td>
              <td><input type="text" name="textfield689" width="95" /></td>
              <td><input type="text" name="textfield6816" width="95" /></td>
              <td><input type="text" name="textfield6823" width="95" /></td>
              <td><input type="text" name="textfield6830" width="95" /></td>
              <td><input type="text" name="textfield68362" width="180" /></td>
            </tr>
            <tr>
              <td height="29"><input type="text" name="textfield63" width="70" /></td>
              <td><input type="text" name="textfield683" width="95" /></td>
              <td><input type="text" name="textfield73"  width="230"/></td>
              <td><input type="text" name="textfield6810" width="95" /></td>
              <td><input type="text" name="textfield6817" width="95" /></td>
              <td><input type="text" name="textfield6824" width="95" /></td>
              <td><input type="text" name="textfield6831" width="95" /></td>
              <td><input type="text" name="textfield68363" width="180" /></td>
            </tr>
            <tr>
              <td height="29"><input type="text" name="textfield64" width="70" /></td>
              <td><input type="text" name="textfield684" width="95" /></td>
              <td><input type="text" name="textfield74"  width="230"/></td>
              <td><input type="text" name="textfield6811" width="95" /></td>
              <td><input type="text" name="textfield6818" width="95" /></td>
              <td><input type="text" name="textfield6825" width="95" /></td>
              <td><input type="text" name="textfield6832" width="95" /></td>
              <td><input type="text" name="textfield68364" width="180" /></td>
            </tr>
            <tr>
              <td height="23"><p>
                <label></label>
                <input type="text" name="textfield65" width="70" />
              </p>                </td>
              <td><input type="text" name="textfield685" width="95" /></td>
              <td><input type="text" name="textfield75"  width="230"/></td>
              <td><input type="text" name="textfield6812" width="95" /></td>
              <td><input type="text" name="textfield6819" width="95" /></td>
              <td><input type="text" name="textfield6826" width="95" /></td>
              <td><input type="text" name="textfield6833" width="95" /></td>
              <td><input type="text" name="textfield68365" width="180" /></td>
            </tr>
            <tr>
              <td height="23"><input type="text" name="textfield66" width="70" /></td>
              <td><input type="text" name="textfield686" width="95" /></td>
              <td><input type="text" name="textfield76"  width="230"/></td>
              <td><input type="text" name="textfield6814" width="95" /></td>
              <td><input type="text" name="textfield6820" width="95" /></td>
              <td><input type="text" name="textfield6827" width="95" /></td>
              <td><input type="text" name="textfield6834" width="95" /></td>
              <td><input type="text" name="textfield68366" width="180" /></td>
            </tr>
            <tr>
              <td height="23"><input type="text" name="textfield67" width="70" /></td>
              <td><input type="text" name="textfield687" width="95" /></td>
              <td><input type="text" name="textfield77"  width="230"/></td>
              <td><input type="text" name="textfield6813" width="95" /></td>
              <td><input type="text" name="textfield6821" width="95" /></td>
              <td><input type="text" name="textfield6828" width="95" /></td>
              <td><input type="text" name="textfield6835" width="95" /></td>
              <td><input type="text" name="textfield68367" width="180" /></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td width="69" rowspan="2"><p>nom:</p>            </td>
          <td height="14" colspan="2"><div align="center">Marchandise</div></td>
          <td height="14" colspan="2"><div align="center">Comptabilit&eacute;</div></td>
          </tr>
        <tr>
          <td width="205"><div align="center">Livr&eacute;e par </div></td>
          <td height="23"><div align="center">R&eacute;c&eacute;ptionn&eacute;e par </div></td>
          <td height="23"><div align="center">R&eacute;c&eacute;ptionn&eacute;e par </div></td>
          <td height="23"><div align="center">Journal des sorties </div></td>
        </tr>
        <tr>
          <td height="33">prenom:</td>
          <td><label>
            <input type="text" name="textfield8" width="200" />
          </label></td>
          <td height="6"><p>.
            <input type="text" name="textfield823" width="200" />
          </p>
              <p>&nbsp;</p>            </td>
          <td height="6"><p>
            <input type="text" name="textfield824" width="200" />
          </p>
              <p>&nbsp;</p>            </td>
          <td height="6"><p>
            <input type="text" name="textfield825" width="200" />
          </p>
              <p>&nbsp;</p>            </td>
        </tr>
        <tr>
          <td width="69" height="23">fonction:</td>
          <td><input type="text" name="textfield82" width="200" /></td>
          <td height="7"><input type="text" name="textfield822" width="200" /></td>
          <td height="7"><input type="text" name="textfield826" width="200" /></td>
          <td height="7"><input type="text" name="textfield827" width="200" /></td>
        </tr>
        <tr>
          <td height="7">signature:</td>
          <td><p>
            <input type="text" name="textfield83" width="200"  height="30"/>
          </p>            </td>
          <td height="7"><input type="text" name="textfield832" width="200"  height="30"/></td>
          <td height="7"><input type="text" name="textfield833" width="200"  height="30"/></td>
          <td height="7"><input type="text" name="textfield834" width="200"  height="30"/></td>
        </tr>
        <tr>
          <td height="105" colspan="3"><table width="489" height="64" border="0">
            <tr>
              <td width="139"><p>Mati&egrave;res premi&egrave;re</p>
                <p>Mati&egrave;res auxiliaires</p>
                <p>Fournitures  </p></td>
              <td width="127"><p>Petit outillage</p>
                <p>PR &eacute;quipement</p>
                <p>PR v&eacute;hicule </p></td>
              <td width="199"><p>Produits Semi-Finis</p>
                <p>D&eacute;chets et rebuts</p>
                <p>Autres </p></td>
            </tr>
          </table></td>
          <td height="105" colspan="2"><p>Observation : ..............................................................................................................</p>
            <p>...................................................................................................................................</p>
            <p>................................................................................................................................... </p></td>
          </tr>
      </table></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
