<?php
mysql_connect('localhost','root','') or die ('erreur');
mysql_select_db('application') or die ('erreur02');
?>
