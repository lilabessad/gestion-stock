<?php session_start();include('maconnec.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans nom</title>

<style type="text/css">
<!--
.Style1 {	font-size: 36px;
	color: #FF0000;
}
.Style2 {font-size: 18px}
.Style3 {font-size: 18px; color: #0000FF; }
-->
</style>
</head>
<body>
<?php if (isset($_POST['valid'])){
$c = $_POST['codearticle'];
$req = mysql_query("select * from  article where code_art = '$c'");
$donne = mysql_fetch_array($req);
}
?>
<form id="form1" name="form1" method="post" action="mouve.php"  onsubmit=" return valider(); ">
<table width="876" height="588" border="6" align="center">
    <tr>
      <td width="876" height="584"><table width="950" height="580" border="0" background="photom&eacute;moire/aaali.jpg">
          <tr>
            <td height="43" colspan="2" bgcolor="#FFFFCC"><div align="center" class="Style1">Mouvement de r&eacute;ception </div></td>
          </tr>
          <tr>
            <td width="569" height="44"><div align="left" class="Style3">Saisissez le code d'article pour le quel vous voulez fair le mouvement </div></td>
            <td width="297"><label>code article
              <input name="codearticle" type="text" id="codearticle" />
              </label>
              <label>
                <input name="valid" type="submit" id="valid" value="Valider" />
                <?php 
if(isset($_POST['valid'])){
			?>
            </label></td>
          </tr>
          <tr>
            <td height="23" colspan="2"><span class="Style3 Style2">Veuillez completer les champs: </span></td>
          </tr>
          <tr>
            <td height="61" colspan="2"><table width="857" height="56" border="2">
                <tr>
                  <td width="173"><div align="center">Code article </div></td>
                  <td width="166"><div align="center">D&eacute;signation </div></td>
                  <td width="225"><div align="center">Unit&eacute; de m&eacute;sure </div></td>
                  <td width="263"><div align="center">Quantit&eacute;( manquante/en plus) </div></td>
                </tr>
                <tr>
                  <td height="23"><?php echo $donne['code_art']; ?></td>
                  <td><?php echo $donne['des_art']; ?></td>
                  <td><?php echo $donne['unit_mesur']; ?></td>
                  <td align="center"><label> </label>
                      <label>
                      <input name="Quantit&eacute; manquante" type="text" id="Quantit&eacute; manquante" />
                      </label>
                      <div align="left"></div></td>
                </tr>
                <?php } ?>
            </table></td>
          </tr>
          <tr>
            <td height="30"><table width="569" border="0">
                <tr>
                  <td width="177" height="24">Nature du mouvement
                    <label></label></td>
                  <td width="382"><input name="natmov" type="text" id="natmov" /></td>
                </tr>
              </table>
            <label></label></td>
            <td rowspan="5"><a href="mouvr&eacute;cent.html">Afficher un mouvement r&eacute;cent </a></td>
          </tr>
          <tr>
            <td height="49"><table width="564" border="0">
                <tr>
                  <td width="175" height="24">Num&eacute;ro livraison
                    <label></label></td>
                  <td width="379"><input name="numliv" type="text" id="numliv" /></td>
                </tr>
              </table>
            <label></label></td>
          </tr>
          <tr>
            <td height="30"><table width="555" border="0">
                <tr>
                  <td width="174" height="24">Date de mouvement
                    <label></label></td>
                  <td width="371"><input name="datmov" type="text" id="datmov" /></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td height="30"><table width="550" border="0">
                <tr>
                  <td width="174" height="24">Service &eacute;metteur
                    <label></label></td>
                  <td width="366"><input name="servemet" type="text" id="servemet" /></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td height="30"><table width="533" border="0">
                <tr>
                  <td width="174" height="24">Num&eacute;ro de mouvement
                    <label></label></td>
                  <td width="349"><input name="nummov" type="text" id="nummov" /></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td height="31" colspan="2"><div align="center">
                <label>
                <input type="submit" name="Submit" value="Envoyer" />
                </label>
            </div></td>
          </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
