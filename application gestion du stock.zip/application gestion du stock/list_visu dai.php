<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>visualisation listage</title>

<style type="text/css">
<!--
.Style8 {color: #FFDF00}
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="1256" height="599" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1228" height="575"><table width="1223" height="722" border="0" align="center">
        <tr>
          <td height="58" colspan="3" bgcolor="#0000FF"><div align="center">
              <h1 class="Style8">LISTAGE ET VISUALISATION D.A.I:</h1>
          </div></td>
        </tr>
        <tr>
          <td width="258" height="66"><div align="center">
              <h2><strong>Numéro de D.A.I:</strong></h2>
          </div></td>
          <td width="172"><label>
            <input type="text" name="nv" id="nv" />
          </label></td>
          <td width="779"><label>
            <input type="submit" name="bv" id="bv" value="OK" />
          </label></td>
        </tr>
        <tr>
          <td height="62"><div align="center">
              <h2><strong>Code article:</strong></h2>
          </div></td>
          <td width="172"><label>
            <input type="text" name="ca" id="ca" />
          </label></td>
          <td width="779"><label>
            <input type="submit" name="ca2" id="ca2" value="OK" />
          </label></td>
        </tr>
        <tr>
          <td height="62"><div align="center">
              <h2><strong>Suivi de la D.A.I</strong>:</h2>
          </div></td>
          <td>de la bdd</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="93"><label></label>
            <table width="200" border="5" bordercolor="#F0F0F0">
              <tr>
                <td><input type="submit" name="entete" id="entete" value="      Visualisation de l'êntete de la D.A.I     " /></td>
              </tr>
            </table></td>
          <td rowspan="3">&nbsp;</td>
          <td rowspan="3"><table width="759" height="304" border="5" align="center" bordercolor="#FF5F00">
              <tr>
                <td height="37">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td height="251">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="108"><label></label>
            <table width="282" border="5" bordercolor="#FF5F00">
              <tr>
                <td width="264"><input type="submit" name="DETAIL" id="DETAIL" value="      Visualisation d'une ligne d'une D.A.I     " /></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="106"><label></label>
            <table width="200" border="5" bordercolor="#FF5F00">
              <tr>
                <td><input type="submit" name="articl" id="articl" value="Liste des cadences d'une ligne d'une D.A.I" /></td>
              </tr>
            </table></td>
        </tr>
        

      </table>      
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
