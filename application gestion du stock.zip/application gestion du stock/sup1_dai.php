<?php include('connection.php');
$v= $_POST['se'];
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Document sans titre</title>
<script type="text/javascript">
function valider(){ 
 if(document.form1.sign.value == "signe") {
   alert("Cette demande est signée impossible de la supprimer!");
   return false;
  }
  else {if (confirm("Voulez vous vraiment supprimer cette demande??")){
  alert("la demande a été supprimée avec succé!");
  return true;
  } else {return false;}
  }}
</script>
<style type="text/css">
<!--
.Style1 {	color: #FFFF00;
	font-weight: bold;
}
.Style2 {	color: #FF0000;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<?php
$sql1= "select numdai,origine,demission,statut,objet,signature from dai where numdai='$v'" ;
$r1=mysql_query ($sql1);
IF (!$r1) {
   die('Requête invalide : ' . mysql_error());
}
?>
<form id="form1" name="form1" method="post" action="ds1 dai.php" onsubmit="return valider()">
  <table width="1194" height="439" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1166" height="415"><table width="1165" height="374" border="0" align="center">
          <?php
  while( $data=mysql_fetch_array ($r1))
  {
  ?>
          <tr>
            <td height="18" colspan="4"><div align="center">
                <h3 align="left"><a href="edition.php" onclick="edition();return false;"><img src="images/lkj.png" alt="im" width="29" height="24" />EDITER </a></h3>
            </div></td>
          </tr>
          <tr>
            <td height="18" colspan="4" bgcolor="#0000FF"><div align="center">
              <h1><span class="Style1">Demande d'achat interne(D.A.I)</span></h1>
            </div></td>
          </tr>
          <tr>
            <td height="38"><div align="right"><strong>Numéro de la D.A.It:</strong></div></td>
            <td height="38"><input type="text" name="s" id="s" value="<?php echo $data['numdai'];?>" readonly="readonly" /></td>
            <td height="38"><div align="right"><strong>Date d'emission::</strong></div></td>
            <td width="206"><input name="dm" type="text" id="dm" readonly="readonly" value="<?php echo $data['demission'];?>" size="25" /></td>
          </tr>
          <tr>
            <td width="238" height="42"><div align="right"></div></td>
            <td width="302"><div align="right">
                <h3><strong>Origine de la D.A.I:</strong></h3>
            </div></td>
            <td width="401"><input name="natur" type="text" id="natur" readonly="readonly" value="<?php echo $data['origine'];?>" size="50" /></td>
            <td height="42">&nbsp;</td>
          </tr>
          <tr>
            <td height="17"><div align="right"><strong>Statut d'achat:</strong></div></td>
            <td height="17"><h2>
                <input type="text" name="nm" id="nm" readonly="readonly" value="<?php echo $data['statut'];?>" />
            </h2></td>
            <td height="17"><div align="right"><strong>Objet de la D.A.I:</strong></div></td>
            <td height="17"><input type="text" name="n" id="n" readonly="readonly" value="<?php echo $data['objet'];?>" /></td>
          </tr>
          <tr>
            <td height="59"><p>&nbsp;</p>
                <p align="right"><a href="edition.php" onclick="edition();return false;"></a>
                    <label></label>
              </p></td>
            <td height="59"><div align="right">
                <h3>Signature:</h3>
            </div></td>
            <td height="59"><label>
              <input type="text" name="sign" id="sign" readonly="readonly" value="<?php echo $data['signature'];?>" />
            </label></td>
           
            <td height="59">&nbsp;</td>
          </tr>
           
          <tr>
            <td height="56" colspan="4"><div align="right">
            
            
                <table width="1129" height="90" border="0" align="center">
                  <tr>
                    <td colspan="4" bgcolor="#A0A0A4"><div align="center">
                        <h3><strong>ARTICLE</strong></h3>
                    </div></td>
                  </tr>
                  <tr>
                    <td width="75" bgcolor="#FFCCFF"><div align="center"><strong>CODE</strong></div></td>
                    <td width="290" bgcolor="#FFCCFF"><div align="center"><strong>DESIGNATION</strong></div></td>
                    <td width="65" bgcolor="#FFCCFF"><div align="center"><strong>UNITE</strong></div></td>
                    <td width="239" bgcolor="#FFCCFF"><div align="center"><strong>QUANTITE DU MOUVEMENT</strong></div></td>
                  </tr>
              
                  <tr>
                    <td height="21" bgcolor="#FFFBF0">&nbsp;</td>
                    <td bgcolor="#FFFBF0">&nbsp;</td>
                    <td bgcolor="#FFFBF0">&nbsp;</td>
                    <td bgcolor="#FFFBF0">&nbsp;</td>
                  </tr>
                </table>
              <label>
                <input type="reset" name="annuler" id="annuler" value="Annuler"/>
                </label>
                <input type="submit" name="si" id="si" value="Supprimer" />
            </div></td>
          </tr>
         <?php } ?>
        </table>
          <h6>&nbsp;</h6></td>
    </tr>
    
  </table>
</form>
</body>
</html>
<script type="text/javascript">
<?php 
$sql=("DELETE FROM dai WHERE numdai ='$v'");
$rp=mysql_query ($sql);
IF (!$rp) {
   die('Requête invalide : ' . mysql_error());
}
header('Location: detail_sup_dai.php');
header('Location: ds1 dai.php');
?></script>

