<?php include('connection.php');
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Document sans titre</title>
<script type="text/javascript">
function valider(){
 
 if(document.form1.sign.value =="signé") {
   alert("Ce mouvement de reception est deja signé!");
   return false;
  }
  }
  </script>
  
<style type="text/css">
<!--
.Style3 {
	color: #FFFF00;
	font-weight: bold;
}
-->
</style>
<script type="text/javascript">
function edition()
    {
    options = "Width=700,Height=700" ;
    window.open( "edition.php", "edition", options ) ;
    }
	
	</script>
</head>

<body>

<form id="form1" name="form1" method="post" action="" onsubmit="return valider();">
<?php
$rech=$_POST['t'];
$sql= "select code_art,des_art,unit_mesur from article where code_art='$rech'" ;
$r=mysql_query ($sql);
IF (!$r) {
   die('Requête invalide : ' . mysql_error());
}?>
  <table width="1194" height="212" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
  
    <tr>
      <td width="1166" height="188"><table width="1174" height="153" border="0">
        <tr>
  
          <?php
  while( $tab=mysql_fetch_array ($r))
  {?>
          <td height="36" colspan="3" bgcolor="#0000FF"><div align="center" class="Style3">
                  <h2>ARTICLE N°:<?php echo $tab['code_art'];?></h2>
          </div></td>
        </tr>
  
        <tr>
          <td width="351" height="54">CODE
            <label>
              <input type="text" name="cd" id="cd" value="<?php echo $tab['code_art'];?>" />
            </label></td>
             
          <td width="362">DESIGNATION
            <label>
              <input type="text" name="de" id="de"   value="<?php echo $tab['des_art'];?>"/>
            </label></td>
          <td width="447">UNITE DE MESURE
            <label>
              <input type="text" name="um" id="um"  value="<?php echo $tab['unit_mesur'];?>" />
            </label></td>
        </tr>
        <tr>
          <td width="351" height="55"><h3><strong>Disponible en magasin:</strong>
            <label>
            <input type="text" name="dm" id="dm" />
            </label>
          </h3></td>
          
          <td width="362">&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      
<tr></tr>
 <?php }?>
      </table> 
      <h6>&nbsp;</h6></td>
    </tr>
   
  </table>
</form>
</body>
</html>

