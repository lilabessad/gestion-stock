<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>application sur gestion de stock</title>
<link rel="stylesheet" href="css/style.css"/>
<script type="text/javascript">
//<![CDATA[

function valider(){
// si la valeur du champ prenom est non vide
if(document.form1.jour.value !="jour" && document.form1.mois.value !="Mois" && document.form1.anne.value !="Ann�e" && document.form1.odai.value !="" && document.form1.odai.value !="" && document.form1.statut[0].checked!=false || document.form1.statut[1].checked!=false && (document.form1.stat[0].checked!=false || document.form1.stat[1].checked!=false || document.form1.stat[2].checked!=false) ) {
// les donn�es sont ok, on peut envoyer le formulaire 
return true;
}
else {
// sinon on affiche un message
alert("Veuillez saisir toutes les informations necessaires pour votre D.A.I");
// et on indique de ne pas envoyer le formulaire
return false;
}

}
function assure(){
  // si la valeur de la dai ni pas saisir
  if(document.form1.supd.value !="" )
        {
		alert ("voulez vous vraiment supprimer cette D.A.I ??");
    // les donn�es sont ok, on peut envoyer le formulaire    
    return true;
  }
  else {
    // sinon on affiche un message
    alert("Veuillez saisir toutes les informations necessaires pour votre D.A.I");
    // et on indique de ne pas envoyer le formulaire
    return false;
  }
  
}
</script>

<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body onload="MM_preloadImages('images/dy.jpg')">
<form id="form1" name="form1" method="post" action="" onsubmit="return assure();" >
<table width="950" height="582" border="4" cellpadding="2" align="center" bordercolor="#999999" background="images/blue.jpg">
<tr>
<th height="118" scope="col"><table width="482" height="112" border="0" align="left" cellpadding="2">
  <tr>
    <td width="272" height="49">&nbsp;</td>
  </tr>
  <tr>
    <td height="27"><a href="gestionnaire.php"><img src="images/fe.png" width="72" height="37" border="0" /></a></td>
  </tr>
</table>
<table width="290" height="112" border="0" align="right" cellpadding="2">
<tr>
<th width="74" scope="col">&nbsp;</th>
<th width="145" height="39" scope="col"> <span class="Style1"> Gestionnaire </span></th>
<th width="72" rowspan="2" scope="col"><img src="images/logoEniem.jpg" width="82" height="100" /></th>
</tr>
<tr>
<th width="74" scope="col"><img src="images/azeeezere.jpg" width="58" height="63" /></th>
<th height="67" scope="col"><label></label>
<a href="essai.php">Deconnecter</a><img src="images/vrg.jpg" width="31" height="30" /></th>
</tr>
</table></th>
</tr>
<tr>
<td height="388" valign="top"><div align="center">
  <table width="793" height="292" border="1" cellpadding="2">
    <tr>
      <td height="39" colspan="2"><div align="center"><span class="Style2">Supprimer une Demande Achat Interne(D.A.I) </span></div></td>
    </tr>
    <tr>
      <td colspan="2"><div align="right"><span class="Style3">Affection:gestion de stock de l'unite cuisson(ENIEM)</span></div></td>
    </tr>
    <tr>
      <td height="42" colspan="2"><span class="Style1">Agent:
        </span><label>
        <input type="text" name="textfield" />
        </label></td>
    </tr>
    <tr>
      <td width="303" height="43"><span class="Style1">numero D.A.I:
        </span><label>
        <input type="text" name="supd" />
        </label></td>
      <td width="398"><span class="Style1">Date d'emission:
        </span><label><em><strong>
        <select name="jour" id="jumpMenu" onchange="">
          <option>jour</option>
          <option>01</option>
          <option>02</option>
          <option>03</option>
          <option>04</option>
          <option>05</option>
          <option>06</option>
          <option>07</option>
          <option>08</option>
          <option>09</option>
          <option>10</option>
          <option>11</option>
          <option>12</option>
          <option>13</option>
          <option>14</option>
          <option>15</option>
          <option>16</option>
          <option>17</option>
          <option>18</option>
          <option>19</option>
          <option>20</option>
          <option>21</option>
          <option>22</option>
          <option>23</option>
          <option>24</option>
          <option>25</option>
          <option>26</option>
          <option>27</option>
          <option>28</option>
          <option>29</option>
          <option>30</option>
          <option>31</option>
        </select>
        </strong></em><em><strong>
        <select name="mois" id="jumpMenu2" onchange="">
          <option>Mois</option>
          <option>Janvier</option>
          <option>Fevrier</option>
          <option>Mars</option>
          <option>Avril</option>
          <option>Mai</option>
          <option>Juin</option>
          <option>Juillet</option>
          <option>Aout</option>
          <option>Septembre</option>
          <option>Octobre</option>
          <option>Novembre</option>
          <option>Decembre</option>
        </select>
        </strong></em><em><strong>
        <select name="anne" id="jumpMenu3" onchange="">
          <option>Ann&eacute;e</option>
          <option>2000</option>
          <option>2001</option>
          <option>2002</option>
          <option>2003</option>
          <option>2004</option>
          <option>2005</option>
          <option>2006</option>
          <option>2007</option>
          <option>2008</option>
          <option>2009</option>
          <option>2010</option>
          <option>2011</option>
          <option>2012</option>
          <option>2013</option>
          <option>2014</option>
          <option>2015</option>
          <option>2016</option>
          <option>2017</option>
          <option>2018</option>
          <option>2019</option>
          <option>2020</option>
        </select>
        </strong></em></label></td>
    </tr>
    <tr>
      <td height="41" colspan="2"><span class="Style1">objet de D.A.I:
        </span><label>
        <input type="text" name="textfield4" />
        </label></td>
    </tr>
    <tr>
      <td height="59" colspan="2"><table width="179" height="45" border="0" align="right" cellpadding="2">
        <tr>
          <td width="76"><label>
            <input type="submit" name="Submit" value="Supprimer" />
          </label></td>
          <td width="101"><label>
            <input name="reset" type="submit" id="reset" value="Annuler" />
          </label></td>
        </tr>
      </table></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
<tr>
  <td height="60" bgcolor="#C0C0C0"><?php
		include('header.php'); 
		include('footer.php');

	?></td>
  </table>
<table width="300" border="1" cellpadding="2">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
</form>
</body>
</html>


