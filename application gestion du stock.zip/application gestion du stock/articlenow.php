<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style15 {color: #CC0000;
	font-size: 36px;
	font-weight: bold;
	font-style: italic;
}
.Style11 {font-size: 24px; color: #0000CC; }
.Style12 {font-size: 24px;
	font-weight: bold;
	color: #0000CC;
}
.Style14 {font-size: 24px;
	color: #FF0000;
}
.Style16 {font-size: 18px}
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="950" height="580" border="6"align="center"   bordercolor="#0000FF" bgcolor="#CCCCCC">
    <tr>
      <td><table width="950" height="573" border="2">
        <tr>
          <td height="73"><table width="937" height="72" border="2">
            <tr>
              <td width="229"><img src="photom&eacute;moire/lkhlk.jpg" width="105" height="76" /></td>
              <td width="354"><div align="center"><span class="Style15">ARTICLE</span></div></td>
              <td width="330"><div align="right"><img src="photom&eacute;moire/LUHUG.jpg" width="67" height="64" /></div></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td height="53"><div align="right"><span class="Style11">Code article
            <input type="text" name="textfield32" />
          </span><img src="photom&eacute;moire/mrr.jpg" width="55" height="43" border="0" /></div></td>
        </tr>
        <tr>
          <td><p></p>
            <table width="845" height="338" border="2">
              <tr>
                <th width="344" height="31" scope="row"><span class="Style14">** Operations sur les articles ** </span></th>
                <td colspan="2"><div align="center" class="Style11">liste des articles </div></td>
              </tr>
              <tr>
                <th height="109" scope="row"><p class="Style12"><a href="lienprmodif.html" class="Style16">MODIFIER UN ARTICLE </a></p>
                    <p class="Style12"><a href="lienprmodif.html"><img src="photom&eacute;moire/modifier-adresse-ip.png" width="92" height="62" /></a></p></th>
                <td colspan="2" rowspan="2"><table width="385" height="77" border="2" align="center">
                    <tr>
                      <th width="77" height="46" rowspan="2" scope="row"><div align="center">code</div></th>
                      <td width="160" rowspan="2"><div align="center">designation</div></td>
                      <td width="114" rowspan="2"><div align="center">init&eacute; de m&eacute;sur</div></td>
                      <td height="23" colspan="4"><div align="center">coefficients</div></td>
                    </tr>
                    <tr>
                      <td width="40" height="23"><div align="center">coef1(</div></td>
                      <td width="34"><div align="center">coef2</div></td>
                      <td width="34"><div align="center">coef3</div></td>
                      <td width="34"><div align="center">coef4</div></td>
                    </tr>
                    <tr>
                      <th scope="row">&nbsp;</th>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td colspan="4">&nbsp;</td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <th height="82" scope="row"><p class="Style11"><a href="lienprsuppresduprod.html" class="Style16">SUPPRIMER UN ARTICLE </a></p>
                    <p class="Style11"><a href="lienprsuppresduprod.html"><img src="photom&eacute;moire/images_052.jpg" width="68" height="35" /></a></p></th>
              </tr>
              <tr>
                <th height="92" scope="row"><p class="Style11"><a href="lienprretour.html" class="Style16">QUITTER</a></p>
                    <p class="Style11"><a href="lienprretour.html"><img src="photom&eacute;moire/hk.jpg" width="78" height="45" /></a></p></th>
                <td width="73"><div align="center"><span class="Style11">ajouter un article: </span></div></td>
                <td width="404"><table width="332" height="73" border="2" align="center">
                    <tr>
                      <th scope="row">&nbsp;</th>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <th scope="row">&nbsp;</th>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                </table></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
