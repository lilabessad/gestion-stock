<?php 
session_start();include('connection.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>visualisation listage</title>


<style type="text/css">
<!--
.Style8 {color: #FFDF00}
-->
</style>
</head>

<body>
<?php
$sql= 'select id_dai,numdai,origine,demission,statut,objet,signature from dai';
$rep=mysql_query ($sql);
IF (!$rep) {
   die('Requête invalide : ' . mysql_error());
}
?>

<form id="form1" name="form1" method="post" action="list_visu dai.php">
  <table width="1299" height="158" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1271" height="134"><table width="1271" height="108" border="0" align="center">
        <tr>
          <td height="38" bgcolor="#0000FF"><div align="center">
              <h1 class="Style8">LISTAGE DES D.A.I:</h1>
          </div></td>
        </tr>
        
        
        
        <tr>
          <td width="1059" height="64">
          
          <table width="1263" height="62" border="5" align="center" bordercolor="#F0F0F0" >
              <tr>
                <td width="49" height="23" bgcolor="#A0A0A4">N°</td>
                <td width="193" bgcolor="#A0A0A4">NUMERO DE D.A.I</td>
                <td width="230" bgcolor="#A0A0A4">ORIGINE DE LA D.A.I</td>
                <td width="204" bgcolor="#A0A0A4">DATE D'EMISSION</td>
                <td width="258" bgcolor="#A0A0A4">STATUT D'ACHAT</td>
                <td colspan="2" bgcolor="#A0A0A4">OBJET DE D.A.I</td>
                </tr>
    <?php
  while( $data=mysql_fetch_array ($rep))
  {
  ?>
              <tr>
                <td height="23" bgcolor="#FFFBF0"><?php echo $data['id_dai'];?>&nbsp;</td>
                <td height="23" bgcolor="#FFFBF0"><?php echo $data['numdai'];?></td>
                <td bgcolor="#FFFBF0"><?php echo $data['origine'];?></td>
                <td bgcolor="#FFFBF0"><?php echo $data['demission'];?></td>
                <td bgcolor="#FFFBF0"><?php echo $data['statut'];?></td>
                <td width="140" bgcolor="#FFFBF0"><?php echo $data['objet'];?></td>
                <td width="135" bgcolor="#FFFBF0"><a href="detail_mod_dai.php?num=<?php echo $data ['id_dai']; ?>">MODIFIER</a></td>
                </tr>
   <?php } ?>
          </table>          </td>
        </tr>
      </table>      
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
