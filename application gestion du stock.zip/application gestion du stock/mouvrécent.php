<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans nom</title>
<style type="text/css">
<!--
.Style1 {
	font-size: 36px;
	color: #990000;
}
.Style3 {font-size: 18px}
.Style7 {font-size: 20px; }
.Style9 {font-size: 18px; color: #006400; }
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="950" height="580" border="6" align="center" bordercolor="#CC00FF" bgcolor="#FFFFFF">
    <tr>
      <td><table width="950" height="613" border="2" align="center" bgcolor="#FF99FF">
    <tr>
      <td height="23" bgcolor="#FF99FF"><div align="center" class="Style1">Mouvement de r&eacute;ception </div></td>
    </tr>
    <tr>
      <td height="48"><div align="left" class="Style3">
        <p class="Style7">Tapez le num&eacute;ro de votre mouvement que vous souhaitez voir: </p>
        <p align="center"><span class="Style7">Num&eacute;ro mouvement</span>
          <label>
          <input name="Num&eacute;ro mouvement" type="text" id="Num&eacute;ro mouvement" />
          </label>
          <img src="photom&eacute;moire/images_036.jpg" width="34" height="36" /> </p>
      </div></td>
      </tr>
    <tr>
      <td height="23"><span class="Style9">voici les informations cocernant se mouvement : </span></td>
    </tr>
    <tr>
      <td height="82"><table width="944" height="79" border="2">
        <tr>
          <td><div align="center" class="Style3">Code article </div></td>
          <td><div align="center" class="Style3">D&eacute;signation </div></td>
          <td><div align="center" class="Style3">Unit&eacute; de m&eacute;sure </div></td>
          <td><div align="center" class="Style3">Quantit&eacute; manquante </div></td>
        </tr>
        <tr>
          <td height="45"><label>
            <div align="center">
              <input name="Code article" type="text" id="Code article" />
              </div>
          </label></td>
          <td><label>
            </label>
            <label>
            <input name="D&eacute;signation" type="text" id="D&eacute;signation" />
            </label></td>
          <td><label>
            </label>
            <label>
            <input name="Unit&eacute; de m&eacute;sure" type="text" id="Unit&eacute; de m&eacute;sure" />
            </label></td>
          <td><label>
          <input name="Quantit&eacute; manquante" type="text" id="Quantit&eacute; manquante" />
            </label></td>
        </tr>
      </table></td>
    </tr>
    <tr>
      <td height="36"><table width="945" border="2">
        <tr>
          <td width="190"><span class="Style3">Nature du mouvement
              <label></label>
          </span>            <label></label></td>
          <td width="737"><label>
            <input name="Nature du mouvement" type="text" id="Nature du mouvement" />
          </label></td>
        </tr>
      </table>
      <label></label></td>
    </tr>
    <tr>
      <td><table width="945" border="2">
        <tr>
          <td width="190"><span class="Style3">Num&eacute;ro livraison
              <label></label>
          </span>            <label></label></td>
          <td width="737"><label>
            <input name="Num&eacute;ro livraison" type="text" id="Num&eacute;ro livraison" />
          </label></td>
        </tr>
      </table>        <label></label></td>
    </tr>
    <tr>
      <td><table width="945" border="2">
        <tr>
          <td width="190"><span class="Style3">Date de mouvement
              <label></label>
          </span>            <label></label></td>
          <td width="737"><label>
            <input name="Date de mouvement" type="text" id="Date de mouvement" />
          </label></td>
        </tr>
      </table>        <label></label></td>
    </tr>
    <tr>
      <td><table width="945" border="2">
        <tr>
          <td width="190"><span class="Style3">Service &eacute;metteur
              <label></label>
          </span>            <label></label></td>
          <td width="737"><label>
            <input name="Service &eacute;metteur" type="text" id="Service &eacute;metteur" />
          </label></td>
        </tr>
      </table>
      <label></label></td>
    </tr>
    <tr>
      <td height="50"><table width="945" border="2">
        <tr>
          <td width="190" height="23"><span class="Style3">Num&eacute;ro de mouvement
              <label></label>
          </span>            <label></label></td>
          <td width="737"><label>
            <input name="Num&eacute;ro de mouvement" type="text" id="Num&eacute;ro de mouvement" />
          </label></td>
        </tr>
      </table>
      <label></label></td>
    </tr>
    <tr>
      <td height="50"><table width="945" height="48" border="0">
        <tr>
          <td width="276">&nbsp;</td>
          <td width="97"><label>
            <input type="submit" name="Submit" value="Imprimer" />
          </label></td>
          <td width="558"><input type="submit" name="Submit2" value="Envoyer au chef de service" /></td>
        </tr>
      </table></td>
    </tr>
    </table></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
