<?php 
$sql='select cod_artc, des_artc, unit_mesu, qtit_manq, qtit_plus, nat_mv, num_liv, dat_mv, ser_emt, num_mv from mouvmenrecep';
$res=mysql_query($sql);
$s='select nat_mv from mouvmenrecep';
$r=mysql_query($s);
$a='select num_liv from mouvmenrecep';
$b=mysql_query($a);
$vm='select dat_mv from mouvmenrecep';
$cv=mysql_query($vm);
$zer='select ser_emt from mouvmenrecep';
$mo=mysql_query($zer);
$az='select num_mv from mouvmenrecep';
$wx=mysql_query($az);
?>


  <?php
  while($data=mysql_fetch_array ($res))
  {
  ?>
   <?php } ?>
     <td width="220">Nature de mouvement </td>
                <?php
  while($d=mysql_fetch_array ($r))
  {
  ?>
   <?php } ?>
     <?php
	  
  while($da=mysql_fetch_array ($b))
  {
  ?>
  
   <?php
  while($no=mysql_fetch_array ($cv))
  {
  ?>
   <?php } ?>
   <?php
  while($qp=mysql_fetch_array ($mo))
  {
  ?> <?php } ?>
    <?php
  while($kl=mysql_fetch_array ($wx))
  {
  ?> <?php } ?>