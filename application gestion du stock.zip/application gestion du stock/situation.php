<?php 
session_start();include('connection.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Document sans titre</title>
<script type="text/javascript">
//<![CDATA[

function valider(){
  // si la valeur du champ prenom est non vide
  if(document.form1.art.value !="") {
    // les données sont ok, on peut envoyer le formulaire    
    return true;
  }
  else {
    // sinon on affiche un message
    alert("veuillez saisir le numéro de l'article que vous voulez consulter");
    // et on indique de ne pas envoyer le formulaire
	   document.form1.art.focus();
    return false;
  }
  
}
</script>
<style type="text/css">
<!--
.Style1 {
	color: #FFDF00;
	font-style: italic;
	font-weight: bold;
}
.Style19 {color: #0000FF; font-weight: bold; font-style: italic; font-size: 18px; }
.Style2 {
	color: #0000FF;
	font-style: italic;
	font-weight: bold;
}
.Style3 {
	color: #FF0000;
	font-weight: bold;
	font-style: italic;
}
.Style4 {
	color: #000000;
	font-style: italic;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<?php
if(isset($_POST['valid'])){
$art = $_POST['art'];
$req = mysql_query("select * from article where code_art = '$art'");
$donne = mysql_fetch_array($req);
}
?>
<form id="form1" name="form1" method="post" action="situation.php" onsubmit="return valider(); ">
  <table width="1188" height="565" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1160" height="541"><table width="1167" height="502" border="0" align="center">
        <tr>
          <td height="62" colspan="3" bgcolor="#0000FF"><div align="center">
            <h1 class="Style1">SITUATION D'UN ARTICLE</h1>
          </div></td>
        </tr>
        <tr>
          <td height="21" colspan="3">&nbsp;</td>
        </tr>
        <tr>
          <td width="328" height="43"><div align="center">
            <h2><em><strong>Article:</strong></em></h2>
          </div></td>
          <td width="275"><label>
            <div align="center">
              <input type="text" name="art" id="art" />
              <label><input type="submit" name="valid" id="valid" value="Valider"/></label>
            </div>
			<?php 
if(isset($_POST['valid'])){
			
			?>
          </label></td>
          <td width="550"><div align="center"><?php echo $donne['des_art']; ?></div></td>
        </tr>
        <tr>
          <td height="37"><div align="center">
            <h2><em><strong>Unité: <?php echo $donne['unit_mesur']; ?></strong></em></h2>
          </div></td>
          <td><div align="center">auto(ex:PCE)</div></td>
          <td><div align="center">auto (avec bride????????????????.....etc)</div></td>
        </tr>
        <tr>
          <td height="44" colspan="3"><div align="center" class="Style19">
            <h2>Informations concernants les quantitées:</h2>
          </div></td>
        </tr>
        <tr>
          <td height="35" colspan="2"><div align="center">
            <h2><em><strong>Disponible en magasin:<?php echo $donne['']; ?></strong></em></h2>
          </div></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="31" colspan="2"><div align="center">
            <h2><em><strong>D.A.I non commandées:<?php echo $donne['numdai']; ?></strong></em></h2>
          </div></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="31" colspan="2"><div align="center">
            <h2><em><strong>Livraisons non reçues:<?php echo $donne['numliv']; ?><</strong></em></h2>
          </div></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="35" colspan="2"><div align="center">
            <h2><em><strong>Commandes non livrées:</strong></em></h2>
          </div></td>
          <td>&nbsp;</td>
        </tr>
		<?php } ?>
        <tr>
          <td height="75" colspan="3" valign="top"><h2><em><strong>
              <label>            </label>
              </strong>            
                  <label></label>
              </em>            
                <label></label>
            </h2>            
            <div align="center">
              <h2><span class="Style2">Pour voir le nombre total de pieces pour cet article cliquez sur </span><em><strong>
                <input name="ok" type="submit" class="Style19" id="ok" value="OK" />
              </strong></em></h2>
            </div>
            <label></label></td>
        </tr>
        <tr>
          <td height="30" colspan="2"><div align="center">
            <h2 align="right"><em><strong>Total couverture:</strong></em></h2>
          </div></td>
          <td valign="middle"><h2><em><strong>
            <label>            </label>
            </strong>            
              <label></label>
            </em>            
                <label></label>
                <label>
                <input name="total" type="text" class="Style3" id="total" maxlength="500" />
                </label>
          </h2>            
            <label></label></td>
        </tr>
        <tr>
          <td height="32" colspan="2">&nbsp;</td>
          <td align="right" valign="middle"><div align="right" id="an">

                <div align="right">
                  <input name="button" type="reset" class="Style19" id="button" value="Annuler" />
                  </div>
          </div></td>
        </tr>
      </table>
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
