<?php include ('accebd.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
</head>

<body>
<?php 
$sql='select nom, prenom, adresse, telephone, email,login,motdepass from tableuti';
$res=mysql_query($sql);
?> 
<a href="insert_utilisat.php">nouveau
</a>
<table width="776" height="68" border="2">
  <tr>
    <th height="24" bgcolor="#FF6666" scope="row"><div align="center">nom</div></th>
    <td bgcolor="#FF6666"><div align="center">prenom</div></td>
    <td bgcolor="#FF6666"><div align="center">adresse</div></td>
    <td bgcolor="#FF6666"><div align="center">telephone</div></td>
    <td bgcolor="#FF6666"><div align="center">email</div></td>
    <td bgcolor="#FF6666">login</td>
    <td bgcolor="#FF6666">mot de pass </td>
  </tr>
  <?php
  while($data=mysql_fetch_array ($res))
  {
  ?>
  <tr>
    <th height="34" scope="row">  <?php echo $data ['nom'];?>&nbsp;</th>
    <td> <?php echo $data ['prenom'];?> &nbsp;</td>
    <td> <?php echo $data ['adresse'];?>&nbsp;</td>
    <td> <?php echo $data ['telephone'];?>&nbsp;</td>
    <td> <?php echo $data ['email'];?>&nbsp;</td>
    <td> <?php echo $data ['login'];?>&nbsp;</td>
    <td> <?php echo $data ['motdepass'];?>&nbsp;</td>
  </tr>
  <?php } ?>
</table>
</body>
</html>
