<?php 
session_start();include('connection.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>visualisation listage</title>

<style type="text/css">
<!--
.Style8 {color: #FFDF00}
-->
</style>
</head>

<body>
<?php
$sql= 'select id_dai,numdai,origine,demission,statut,objet,signature from dai';
$rep=mysql_query ($sql);
IF (!$rep) {
   die('Requête invalide : ' . mysql_error());
}
?>

<form id="form1" name="form1" method="post" action="list_visu dai.php">
  <table width="1291" height="363" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1263" height="339"><table width="1223" height="342" border="0" align="center">
        <tr>
          <td height="96" colspan="2" bgcolor="#0000FF"><div align="center">
              <h1 class="Style8">LISTAGE ET VISUALISATION D.A.I:</h1>
          </div></td>
        </tr>
        <tr>
          <td width="154" height="66"><div align="center">
              <h3 align="left"><strong>Numéro de D.A.I:</strong></h3>
          </div></td>
          <td width="1059"><label></label></td>
        </tr>
        
        
        <tr>
          <td height="172"><label></label></td>
          <td>
          
          <table width="1081" height="140" border="5" align="center" bordercolor="#F0F0F0">
              <tr>
                <td width="56" height="61">ORDRE</td>
                <td width="143">NUMERO DE D.A.I</td>
                <td width="171">ORIGINE DE LA D.A.I</td>
                <td width="144">DATE D'EMISSION</td>
                <td width="138">STATUT D'ACHAT</td>
                <td width="166">OBJET DE D.A.I</td>
                <td colspan="2">SINATURE</td>
              </tr>
    <?php
  while( $data=mysql_fetch_array ($rep))
  {
  ?>
              <tr>
                <td height="59"><?php echo $data['id_dai'];?>&nbsp;</td>
                <td height="59"><?php echo $data['numdai'];?></td>
                <td><?php echo $data['origine'];?></td>
                <td><?php echo $data['demission'];?></td>
                <td><?php echo $data['statut'];?></td>
                <td><?php echo $data['objet'];?></td>
                <td width="78"><?php echo $data['signature'];?>&nbsp;</td>
                <td width="125"><h4><a href="detail_dait.php?num=<?php echo $data ['id_dai']; ?>">VOIR DETAILS</a></h4></td>
              </tr>
   <?php } ?>
          </table>          </td>
        </tr>
      </table>      
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
