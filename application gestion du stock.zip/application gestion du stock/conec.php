<?php 
mysql_connect('localhost','root','') or die('erreur');
mysql_select_db('bdmemoire') or die ('erreur1');
?>