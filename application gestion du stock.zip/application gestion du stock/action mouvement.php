<?php 
session_start();include('connection.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style16 {color: #FF5F00}
.Style17 {color: #FF7F00}
-->
</style>
</head>

<body>
<?php
$sql= 'select id_m,nummouv,numliv,naturmouv,dmouvement from mouvement';
$r=mysql_query ($sql);
IF (!$r) {
   die('Requête invalide : ' . mysql_error());
}

?>
<form id="form1" name="form1" method="post" action="">
  <table width="1221" height="191" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1452" height="167"><table width="1194" height="132" border="0" align="center">
        <tr>
          <td width="1184" height="56" colspan="2" bgcolor="#0000FF"><div align="center" class="Style16">
            <h2 class="Style17">MOUVEMENT DE RECEPTION</h2>
          </div></td>
        </tr>
        <tr>
          <td height="55" colspan="2"><table width="1177" height="53" border="0" align="center">
            <tr>
              <td width="108" height="21" bgcolor="#FFFBF0">ORDRE</td>
              <td width="240" bgcolor="#FFFBF0">NUMERO DU MOUVEMENT</td>
              <td width="257" bgcolor="#FFFBF0">NUMERO DE LIVRAISON</td>
              <td width="226" bgcolor="#FFFBF0">NATRE MOUVEMENT</td>
              <td colspan="2" bgcolor="#FFFBF0">DATE DU MOUVEMENT</td>
            </tr>
            <?php
  while($data=mysql_fetch_array($r))
  {
  ?>
            <tr>
              <td height="26" bgcolor="#FFFBF0"><?php echo $data['id_m'];?>&nbsp;</td>
              <td height="26" bgcolor="#FFFBF0"><?php echo $data['nummouv'];?>&nbsp;</td>
              <td bgcolor="#FFFBF0"><?php echo $data['numliv'];?>&nbsp;</td>
              <td bgcolor="#FFFBF0"><?php echo $data['naturmouv'];?>&nbsp;</td>
              <td width="171" bgcolor="#FFFBF0"><?php echo $data['dmouvement'];?>&nbsp;</td>
              <td width="149" bgcolor="#FFFBF0"><a href="detail_mouvement.php?num=<?php echo $data ['nummouv']; ?>">VOIR DETAILS</a>
            </tr>
            <?php
			 }?>
          </table></td>
        </tr>
        
        
        
      </table>
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
