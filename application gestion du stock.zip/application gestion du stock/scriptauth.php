<?php include('accebd.php');
$l=$_POST['login'];
$m=$_POST['motdepass'];
$sql= 'select * from tableuti where login="'.$l.'" and motdepass="'.$m.'"';
$r=mysql_query($sql);
$nbl= mysql_num_rows($r);

if($nbl==0){
header("location:auth.php");}
else
{
session_start();
$_SESSION['l1']=$l;
header("location:list_utilisateur.php");
}
?>