<?php include('conec.php'); 
$u=$_POST['unit'];
$nu=$_POST['numfich'];
$et=$_POST['etableur'];
$st=$_POST['struct'];
$d=$_POST['datetabl'];
$s=$_POST['signateur'];
$c=$_POST['codartl'];
$des=$_POST['desartl'];
$um=$_POST['unimes'];
$stk=$_POST['stkmin'];
$ma=$_POST['magasi'];
$em=$_POST['emplac'];
$ca=$_POST['cas'];
$da=$_POST['dat'];
$nat=$_POST['natrefr'];
$en=$_POST['entre'];
$sor=$_POST['sorti'];
$sol=$_POST['sold'];
$sql='insert into  fichconcerne (unite, num_fich, etablisseur, structure, dat_etab, signateur, cod_artcl, des_artcl, unit_mesu, stoc_min, magasinn, emplacmn, rayonn, dat_stcartc, natt_stc, entr_stc, sort_stc, sold) values("'.$u.'","'.$nu.'","'.$et.'","'.$st.'","'.$d.'","'.$s.'","'.$c.'","'.$des.'","'.$um.'","'.$stk.'","'.$ma.'","'.$em.'","'.$ca.'","'.$da.'","'.$nat.'","'.$en.'","'.$sor.'","'.$sol.'")';
mysql_query($sql);
?>

