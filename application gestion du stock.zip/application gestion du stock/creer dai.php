<?php 
session_start();include('connection.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>lidia</title>
<script type="text/javascript">
//<![CDATA[
function valider(){
 if((document.form1.stat[0].checked == false) && (document.form1.stat[1].checked == false) && (document.form1.stat[2].checked == false) && (document.form1.statut[0].checked == false)  && (document.form1.statut[1].checked == false) && (document.form1.odai.value =="") && (document.form1.num.value =="") &&(document.form1.jour.value =="jour") && (document.form1.mois.value =="Mois") && (document.form1.anne.value =="Année")){
   alert("Veuillez remplir tous les champs!");
   return false;
  }
  if(document.form1.num.value == ""){
   alert("Veuillez saisir le numéro de votre D.A.I!");
    document.form1.odai.focus();
   return false;
  }
   if((document.form1.stat[0].checked == false) && (document.form1.stat[1].checked == false) &&( document.form1.stat[2].checked == false)){
   alert("Veuillez choisir l'origine de votre D.A.I !");
   return false;
  }
   if((document.form1.jour.value == "jour")|| (document.form1.mois.value == "Mois")|| (document.form1.anne.value == "Année")) {
   alert("Veuillez compéter la date!");
   return false;
  }
   if(document.form1.statut[0].checked == false && document.form1.statut[1].checked == false) {
   alert("Vous devez préciser le statut d'achat de votre D.A.I!");
   return false;
  }
   if(document.form1.odai.value == ""){
   alert("Veuillez selectionner l'objet de votre D.A.I!");
    document.form1.odai.focus();
   return false;
  }
   
  
    }
</script>
<style type="text/css">
<!--
.Style8 {
	color: #FFDF00;
	font-weight: bold;
	font-style: italic;
}
.Style9 {
	color: #2A0055;
	font-style: italic;
	font-weight: bold;
}
.Style10 {color: #2A0055}
.Style2 {font-family: Verdana, Arial, Helvetica, sans-serif}
.Style11 {	color: #FF7F00;
	font-style: italic;
	font-weight: bold;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>

</head>

<body>
<form id="form1" name="form1" method="post" action="" onsubmit="return valider();" target="lign dai.php">
  <table width="1188" height="839" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1160" height="815"><table width="1174" height="484" border="0" align="center">
        
        <tr>
          <td height="53" colspan="3" bgcolor="#0000FF"><div align="center">
            <h1><span class="Style8">CREATION D'UNE D.A.I</span></h1>
          </div></td>
        </tr>
        <tr>
          <td width="505" height="29"><h3 class="Style10"><em><strong>AGENT:</strong></em></h3></td>
          <td colspan="2"><div align="right">
            <h4><span class="Style9">AFFECTION</span><span class="Style10">:</span>G.S UNITE CUISSON (ENIEM)</h4>
          </div></td>
        </tr>
        
        <tr>
          <td><div align="center">
            <h2><em><strong>Numéro de la D.A.I:</strong></em></h2>
          </div></td>
          <td height="59" colspan="2" valign="top"><p>
            <label></label>
          </p>
            <p>
              <label>
              <input type="text" name="num" id="num" />
              </label>
              <br />
              </p></td>
        </tr>
        <tr>
          <td height="69"><div align="center">
            <h2><em><strong>Origine de la D.A.I:</strong></em></h2>
          </div></td>
          <td height="69" colspan="2"><p>
            <label>
              <input type="radio" name="stat" id="Groupe de boutons radio1_0" />
              Achat divers</label>
          </p>
            <p><br />
                <label>
                <input type="radio" name="stat" id="Groupe de boutons radio1_1" />
                  Production<br />
  <br />
                </label>
                <br />
                <label>
                <input type="radio" name="stat" id="Groupe de boutons radio1_2" />
                  Maintenance</label>
            </p></td>
        </tr>
        
        <tr>
          <td height="30"><h2 align="center"><em><strong>Date d'emission:</strong></em></h2></td>
          <td colspan="2"><div align="center" class="Style2">
            <div align="center"><em><strong>
              page67
              <select name="jour" id="jumpMenu" onchange="">
                <option>jour</option>
                <option>01</option>
                <option>02</option>
                <option>03</option>
                <option>04</option>
                <option>05</option>
                <option>06</option>
                <option>07</option>
                <option>08</option>
                <option>09</option>
                <option>10</option>
                <option>11</option>
                <option>12</option>
                <option>13</option>
                <option>14</option>
                <option>15</option>
                <option>16</option>
                <option>17</option>
                <option>18</option>
                <option>19</option>
                <option>20</option>
                <option>21</option>
                <option>22</option>
                <option>23</option>
                <option>24</option>
                <option>25</option>
                <option>26</option>
                <option>27</option>
                <option>28</option>
                <option>29</option>
                <option>30</option>
                <option>31</option>
              </select>
              <select name="mois" id="jumpMenu2" onchange="">
                <option>Mois</option>
                <option>01</option>
                <option>02</option>
                <option>03</option>
                <option>04</option>
                <option>05</option>
                <option>06</option>
                <option>07</option>
                <option>08</option>
                <option>09</option>
                <option>10</option>
                <option>11</option>
                <option>12</option>
              </select>
              <select name="anne" id="jumpMenu3" onchange="">
                <option>Année</option>
                <option>2000</option>
                <option>2001</option>
                <option>2002</option>
                <option>2003</option>
                <option>2004</option>
                <option>2005</option>
                <option>2006</option>
                <option>2007</option>
                <option>2008</option>
                <option>2009</option>
                <option>2010</option>
                <option>2011</option>
                <option>2012</option>
                <option>2013</option>
                <option>2014</option>
                <option>2015</option>
              </select>
            </strong></em></div>
          </div></td>
        </tr>
        <tr>
          <td height="84"><h2 align="center"><em>Statut d'achat:</em></h2></td>
          <td colspan="2"><p>
            <label>
              <input type="radio" name="statut" value="Achat ferme"/>
              Achat ferme</label>
            </p>
            <p><br />
                <label>
                <input type="radio" name="statut" value="Achat previsionnel" />
                Achat previsionnel</label>
                <br />
              </p></td>
        </tr>
        
        <tr>
          <td height="41"><h2 align="center"><em>Objet de la D.A.I:</em></h2></td>
          <td colspan="2"><label>
            <select name="odai" id="objet dai">
              <option selected="selected"></option>
              <option> Achat conjucturel </option>
              <option> P.G.A </option>
            </select>
          </label></td>
        </tr>
        <tr>
          <td height="26">&nbsp;</td>
          <td width="479"><div align="right">
            <label>
            <input name="creer" type="submit" class="Style9" id="creer" value="    Créer    " onchange="ligne dai.php"/>
            </label>
          </div></td>
          <td width="121"><div align="right">
            <input name="button" type="reset" class="Style9" id="button" value="Annuler" />
          </div></td>
        </tr>
      </table>      
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
<script type="text/javascript">
<?php 
$orig=$_POST['stat'];
$sta=$_POST['statut'];
$obj=$_POST['odai'];
$j=$_POST['jour'];
$m=$_POST['mois'];
$a=$_POST['anne'];
$num=$_POST['num'];
$date=$a."-".$m."-".$j;
$sql="INSERT INTO dai VALUES ('','$num','$orig','$date','$sta','$obj','pas signée')";
$r=mysql_query ($sql);
IF (!$r) {
   die('Requête invalide : ' . mysql_error());
}

 ?>
 </script>
