<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
	<head>
		<!--
    Created by Artisteer v3.0.0.35414
    Base template (without user's data) checked by http://validator.w3.org : "This page is valid XHTML 1.0 Transitional"
    -->
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />
		<title>Acceuil</title>
		<link rel="stylesheet" href="./style.css" type="text/css" media="screen" />
		<!--[if IE 6]><link rel="stylesheet" href="./style.ie6.css" type="text/css" media="screen" /><![endif]-->
		<!--[if IE 7]><link rel="stylesheet" href="./style.ie7.css" type="text/css" media="screen" /><![endif]-->
		<script type="text/javascript" src="./jquery.js"></script>
		<script type="text/javascript" src="./script.js"></script>
	</head>
	<body>
		<div id="art-main">
			<div class="art-header">
				<div class="art-header-center">
					<div class="art-header-jpeg"></div>
				</div>
				<div class="art-header-wrapper">
					<div class="art-header-inner">
						<script type="text/javascript" src="swfobject.js"></script>
						<div id="art-flash-area">
							<div id="art-flash-container">
								<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="1920" height="480" id="art-flash-object">
									<param name="movie" value="images/flash.swf" ></param>
									<param name="quality" value="high" ></param>
									<param name="scale" value="exactfit" ></param>
									<param name="wmode" value="transparent" ></param>
									<param name="flashvars" value="color1=0xFFFFFF&amp;alpha1=.50&amp;framerate1=24&amp;loop=true&amp;wmode=transparent" ></param>
									<param name="swfliveconnect" value="true" ></param>
									<!--[if !IE]>-->
									<object type="application/x-shockwave-flash" data="images/flash.swf" width="1920" height="480">
										<param name="quality" value="high" ></param>
										<param name="scale" value="exactfit" ></param>
										<param name="wmode" value="transparent" ></param>
										<param name="flashvars" value="color1=0xFFFFFF&amp;alpha1=.50&amp;framerate1=24&amp;loop=true&amp;wmode=transparent" ></param>
										<param name="swfliveconnect" value="true" ></param>
										<!--<![endif]-->
										<div class="art-flash-alt"><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" /></a></div>
										<!--[if !IE]>-->
									</object>
									<!--<![endif]-->
								</object>
							</div>
						</div>
						<div class="art-headerobject"></div>
						<div class="art-logo">
							<h1 id="name-text" class="art-logo-name"><a href="./index.html">Association Des Diabetiques</a></h1>
							<h2 id="slogan-text" class="art-logo-text">Tizi-Ouzou</h2>
						</div>
					</div>
				</div>
			</div>
			<div class="art-nav">
				<div class="art-nav-l"></div>
				<div class="art-nav-r"></div>
				<div class="art-nav-wrapper">
					<div class="art-nav-inner">
						<ul class="art-menu">
							<li><a href="./acceuil.php"class="active" ><span class="l"> </span><span class="r"> </span><span class="t">Acceuil</span></a></li>
							<li><a href="./malade.php "><span class="l"> </span><span class="r"> </span><span class="t">Malade</span></a></li>
							<li><a href="./journal.php "><span class="l"> </span><span class="r"> </span><span class="t">Journal</span></a></li>
					        <li><a href="./galerie.php" ><span class="l"> </span><span class="r"> </span><span class="t">Galerie</span></a></li>
							<li><a href="./contact.php" ><span class="l"> </span><span class="r"> </span><span class="t">Contacter-nous</span></a></li>
											   
						</ul>
					</div>
				</div>
			</div>
			<div class="art-sheet">
				<div class="art-sheet-body">
					<div class="art-content-layout">
						<div class="art-content-layout-row">
							<div class="art-layout-cell art-sidebar1">
								<div class="art-vmenublock">
									<div class="art-vmenublock-body">
										<div class="art-vmenublockheader">
											<div class="l"></div>
											<div class="r"></div>
												</div>
										<div class="art-vmenublockcontent">
											<div class="art-vmenublockcontent-body">
												<ul class="art-vmenu">
													<li><a href="./acceuil.php" class="active"><span class="l"> </span><span class="r"> </span><span class="t">Acceuil</span></a></li>
							                        <li><a href="./malade.php "><span class="l"> </span><span class="r"> </span><span class="t">Malade</span></a></li>
			                                         <li><a href="./journal.php "><span class="l"> </span><span class="r"> </span><span class="t">Journal</span></a></li>
					                                 <li><a href="./galerie.php" ><span class="l"> </span><span class="r"> </span><span class="t">Galerie</span></a></li>
											         <li><a href="./contact.php" ><span class="l"> </span><span class="r"> </span><span class="t">Contacter-nous</span></a></li>
											   </ul>
												<div class="cleared"></div>
											</div>
										</div>
										<div class="cleared"></div>
									</div>
								</div>
								<div class="art-block">
									<div class="art-block-body">
										<div class="art-blockcontent">
											<div class="art-blockcontent-body">
												          <div class="art-vmenublock">
									<div class="art-vmenublock-body">
										<div class="art-vmenublockheader">
											<div class="l"></div>
											<div class="r"></div>
											<h3 class="t">Espace Malade</h3>
										</div>
										<div class="art-vmenublockcontent">
											<div class="art-vmenublockcontent-body">
												
												<p><form name="malade" method="post" action=""> 
                                                  <table>
                                                
                                                  <tr><td>Login</td><td><input type="text" name="login_m" /></td></tr>
                                                  <tr><td>Password</td><td><input type="password" name="mdp_m" /></td></tr> 
                                                  <tr><td></td><td><input type="submit" value="connexion" /></td></tr>
                                                  </table>
                                                  </form>
                                                 </p>
                                                 
                                                 
                                                 
                                                
                                                
                                                
                                                
                                                <div class="cleared"></div>
											</div>
										</div>
										<div class="cleared"></div>
									</div>
								</div>
                                
                                
                                  <div class="art-vmenublock">
									<div class="art-vmenublock-body">
										<div class="art-vmenublockheader">
											<div class="l"></div>
											<div class="r"></div>
											<h3 class="t">Espace Medecin</h3>
										</div>
										<div class="art-vmenublockcontent">
											<div class="art-vmenublockcontent-body">
												
												
                                                 
                                                 
                                                 <p><form name="medecin" method="post" action=""> 
                                                  <table>
                                                  <tr><td>Login</td><td><input type="text" name="login_m" /></td></tr>
                                                  <tr><td>Password</td><td><input type="password" name="mdp_m" /></td></tr> 
                                                  <tr><td></td><td><input type="submit" value="connexion" /></td></tr>
                                                  </table>
                                                  </form>
                                                 </p>
                                                
                                                
                                                
                                                
                                                
                                                <div class="cleared"></div>
											</div>
										</div>
										<div class="cleared"></div>
									</div>
								</div>
												<div class="cleared"></div>
											</div>
										</div>
										<div class="cleared"></div>
									</div>
								</div>
								<div class="art-block">
									<div class="art-block-body">
										<div class="art-blockcontent">
											<div class="art-blockcontent-body">
												<div class="cleared"></div>
											</div>
										</div>
										<div class="cleared"></div>
									</div>
								</div>
								<div class="art-block">
									<div class="art-block-body">
										<div class="art-blockcontent">
											<div class="art-blockcontent-body">
												<div>
																								</div>
												<div class="cleared"></div>
											</div>
										</div>
										<div class="cleared"></div>
									</div>
								</div>
								<div class="art-block">
									<div class="art-block-body">
										<div class="art-blockcontent">
											<div class="art-blockcontent-body">
												<div class="cleared"></div>
											</div>
										</div>
										<div class="cleared"></div>
									</div>
								</div>
								<div class="art-block">
									<div class="art-block-body">
										<div class="art-blockcontent">
											<div class="art-blockcontent-body">
												<div class="cleared"></div>
											</div>
										</div>
										<div class="cleared"></div>
									</div>
								</div>
								<div class="cleared"></div>
							</div>
							<div class="art-layout-cell art-content">
								<div class="art-post">
									<div class="art-post-body">
										<div class="art-post-inner art-article">
											<h2 class="art-postheader">Acceuil</h2>
											<div class="art-postcontent">
												<p>Enter Page content here...</p>
												<p><img src="./images/preview.jpg" alt="an image" style="float:left" />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pharetra, tellus sit amet congue vulputate, nisi erat iaculis nibh, vitae feugiat sapien ante eget mauris. Cras elit nisl, rhoncus nec iaculis ultricies, feugiat eget sapien. Pellentesque ac felis tellus.</p>
												<p>Aenean sollicitudin imperdiet arcu, vitae dignissim est posuere id. Duis placerat justo eu nunc interdum ultrices. Phasellus elit dolor, porttitor id consectetur sit amet, posuere id magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
												<p> Suspendisse pharetra auctor pharetra. Nunc a sollicitudin est. Curabitur ullamcorper gravida felis, sit amet scelerisque lorem iaculis sed. Donec vel neque in neque porta venenatis sed sit amet lectus. Fusce ornare elit nisl, feugiat bibendum lorem. Vivamus pretium dictum sem vel laoreet. In fringilla pharetra purus, semper vulputate ligula cursus in. Donec at nunc nec dui laoreet porta eu eu ipsum. Sed eget lacus sit amet risus elementum dictum.</p>
											</div>
											<div class="cleared"></div>
										</div>
										<div class="cleared"></div>
									</div>
								</div>
								<div class="cleared"></div>
							</div>
						</div>
					</div>
					<div class="cleared"></div>
					<div class="cleared"></div>
				</div>
			</div>
			<div class="art-footer">
				<div class="art-footer-t"></div>
				<div class="art-footer-body"><a href="admin.php">Login</a>
					<div class="art-footer-text">
						<p><a href="./#">Link1</a> | <a href="./#">Link2</a> | <a href="./#">Link3</a></p>
						<p>Copyright � 2014. All Rights Reserved.</p>
						<div class="cleared"></div>
						</div>
					<div class="cleared"></div>
				</div>
			</div>
		</div>
	</body>
</html>
