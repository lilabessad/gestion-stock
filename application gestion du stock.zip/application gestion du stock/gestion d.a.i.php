<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>gestion d'une dai</title>
<style type="text/css">
<!--
.Style8 {color: #FFDF00}
.Style10 {color: #2A0000; }
.Style11 {
	color: #FF7F00;
	font-style: italic;
	font-weight: bold;
}
.Style13 {
	color: #A0A0A4;
	font-weight: bold;
	font-style: italic;
}
.Style14 {color: #0000FF}
.Style15 {color: #808080}
-->
</style>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body onload="MM_preloadImages('../rahma/fv.jpg')">
<form id="form1" name="form1" method="post" action="">
  <table width="1256" height="725" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1228" height="721"><table width="1228" height="644" border="0">
        <tr>
          <td height="100" colspan="2"><table width="315" height="96" border="3" bordercolor="#0000FF">
            <tr>
              <td width="80" rowspan="2"><img src="../rahma/fv.jpg" alt="CHEF" width="107" height="80" /></td>
              <td width="186" height="43"><span class="Style11">CHEF DU SERVICE:</span></td>
              </tr>
            <tr>
              <td height="41">&nbsp;</td>
            </tr>
          </table> </td>
        </tr>
        <tr>
          <td width="430" height="538"><table width="387" height="392" border="3" align="center" bordercolor="#0000FF">
            <tr>
              <td width="16" height="107"><h1><span class="Style15">1</span></h1></td>
              <td width="351"><div align="center">
                <h2><span class="Style13">GESTION DES D.A.I</span></h2>
              </div></td>
            </tr>
            <tr>
              <td height="157"><h1 class="Style14">2</h1></td>
              <td><h2 align="center"><span class="Style14"><a href="gestion encours de reception.php">GESTION DE L'ENCOURS DE RECEPTION</a></span></h2></td>
            </tr>
            <tr>
              <td><h1 class="Style14">3</h1></td>
              <td><div align="center">
                <h2><a href="Accueil.php">RETOUR</a></h2>
              </div></td>
            </tr>
          </table></td>
          <td width="788" height="538"><table width="815" height="537" border="5" align="center" bordercolor="#2A1FFF">
            <tr bgcolor="#2A00FF">
              <td bgcolor="#2A00FF"><div align="center">
                  <h1 class="Style8">GESTION DES D.A.I:</h1>
              </div></td>
            </tr>
            <tr>
              <td><div align="center" class="Style10">
                  <h3><em><strong><a href="creer dai.php">CREER UNE D.A.I</a></strong></em></h3>
              </div></td>
            </tr>
            <tr>
              <td><div align="center" class="Style10">
                  <h3><em><strong><a href="mod dai.php">MODIFICATION D'UNE D.A.I</a></strong></em></h3>
              </div></td>
            </tr>
            <tr>
              <td><div align="center" class="Style10">
                  <h3><em><strong><a href="supp dai.php">SUPPRESION D'UNE D.A.I</a></strong></em></h3>
              </div></td>
            </tr>
            <tr>
              <td height="76"><div align="center" class="Style10">
                  <h3><em><strong><a href="sign dai.php">SIGNATURE D'UNE D.A.I</a></strong></em></h3>
              </div></td>
            </tr>
            <tr>
              <td height="67"><div align="center" class="Style10">
                  <h3><em><strong><a href="list_visu dai.php">LISTAGE-VISUALISATION D'UNE D.A.I</a></strong></em></h3>
              </div></td>
            </tr>
          </table></td>
        </tr>
        
        
      </table>      
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
