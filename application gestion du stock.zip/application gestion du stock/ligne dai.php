<?php 
session_start();include('connection.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>saisir les lingnes de la dai</title>
<script type="text/javascript">
//<![CDATA[
function valider(){
 if((document.form1.urgent[0].checked == false) && (document.form1.urgent[1].checked == false) && (document.form1.dld[0].checked == false) && (document.form1.dld[1].checked == false) && (document.form1.ca.value =="") && (document.form1.qd.value =="") && (document.form1.jour.value =="jour") && (document.form1.mois.value =="Mois") && (document.form1.anne.value =="Année")){
   alert("Veuillez remplir tous les champs!");
   return false;
  } if(document.form1.ca.value == ""){
   alert("Veuillez entrer le code de l'article!");
    document.form1.ca.focus();
   return false;
  }
 if(document.form1.qd.value == "") {
   alert("Veuillez préciser la quantité demmandée!");
   document.form1.qd.focus();
   return false;
  }
 if((document.form1.jour.value == "jour")|| (document.form1.mois.value == "Mois")|| (document.form1.anne.value == "Année")) {
   alert("Veuillez compéter la date!");
   return false;
  }
  if(document.form1.urgent[0].checked == false && document.form1.urgent[1].checked == false) {
   alert("Veuillez repondre si c'est une commande urgente!");
   return false;
  } 
  if(document.form1.dld[0].checked == false && document.form1.dld[1].checked == false) {
   alert("Vous devez préciser si c'est la dérniere ligne ou pas!");
   return false;
  }
  
    }
</script>
<style type="text/css">
<!--
.Style11 {
	color: #FFDF00;
	font-style: italic;
	font-weight: bold;
}
.Style2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-style: italic;
}
.Style9 {	color: #2A0055;
	font-style: italic;
	font-weight: bold;
}
.Style19 {color: #0000FF; font-weight: bold; font-style: italic; font-size: 18px; }
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="" onsubmit="return valider();">
  <table width="1249" height="610" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1025" height="541"><table width="1217" height="587" border="0" align="center">
        <tr>
          <td height="48" colspan="4" bgcolor="#0000FF"><div align="center">
            <h1><span class="Style11">SAISIR LES LIGNES DE LA D.A.I</span></h1>
          </div></td>
        </tr>
        <tr>
          <td width="378"><div align="center">
            <h2><em><strong>Numéro de la D.A.I:</strong></em></h2>
          </div></td>
          <td colspan="2"><label>
            <input type="text" name="nd" id="nd" />
          </label></td>
          <td width="243">&nbsp;</td>
        </tr>
        <tr>
          <td><div align="center">
            <h2><em><strong>Date de demande de la D.A.I:</strong></em></h2>
          </div></td>
          <td colspan="2"><label>
            <input type="text" name="dd" id="dd" />
          </label></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><div align="center">
            <h2><em><strong>Numéro de ligne de la D.A.I:</strong></em></h2>
          </div></td>
          <td colspan="2">incrimental</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><div align="center">
            <h2><em><strong>Code d'article:</strong></em></h2>
          </div></td>
          <td colspan="2"><input type="text" name="ca" id="ca" /></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><div align="center">
            <h2><em><strong>Quantité demandée:</strong></em></h2>
          </div></td>
          <td colspan="2"><input type="text" name="qd" id="qd" /></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="70"><div align="center">
            <h2><em><strong>Commande urgente?</strong></em></h2>
          </div></td>
          <td width="264"><em><strong>
            <label>
            <input type="radio" name="urgent" value="bouton radio" id="urgent_0" />
OUI</label>
            <br />
            <label>
            <input type="radio" name="urgent" value="bouton radio" id="urgent_1" />
NON</label>
          </strong></em></td>
          <td width="314"><div align="center">
            <h2><em><strong>Date de la demande:</strong></em></h2>
          </div></td>
          <td><div align="center" class="Style2">
            <div align="left">
              <h3>
                <select name="jour" id="jumpMenu" onchange="">
                  <option>jour</option>
                  <option>01</option>
                  <option>02</option>
                  <option>03</option>
                  <option>04</option>
                  <option>05</option>
                  <option>06</option>
                  <option>07</option>
                  <option>08</option>
                  <option>09</option>
                  <option>10</option>
                  <option>11</option>
                  <option>12</option>
                  <option>13</option>
                  <option>14</option>
                  <option>15</option>
                  <option>16</option>
                  <option>17</option>
                  <option>18</option>
                  <option>19</option>
                  <option>20</option>
                  <option>21</option>
                  <option>22</option>
                  <option>23</option>
                  <option>24</option>
                  <option>25</option>
                  <option>26</option>
                  <option>27</option>
                  <option>28</option>
                  <option>29</option>
                  <option>30</option>
                  <option>31</option>
                </select>
                <select name="mois" id="jumpMenu2" onchange="">
                  <option>Mois</option>
                  <option>janvier</option>
                  <option>février</option>
                  <option>mars</option>
                  <option>avril</option>
                  <option>mai</option>
                  <option>juin</option>
                  <option>juillet</option>
                  <option>août</option>
                  <option>septembre</option>
                  <option>octobre</option>
                  <option>novembre</option>
                  <option>décembre</option>
                </select>
                <select name="anne" id="jumpMenu3" onchange="">
                  <option>Année</option>
                  <option>2000</option>
                  <option>2001</option>
                  <option>2002</option>
                  <option>2003</option>
                  <option>2004</option>
                  <option>2005</option>
                  <option>2006</option>
                  <option>2007</option>
                  <option>2008</option>
                  <option>2009</option>
                  <option>2010</option>
                  <option>2011</option>
                  <option>2012</option>
                  <option>2013</option>
                  <option>2014</option>
                  <option>2015</option>
                </select>
              </h3>
            </div>
          </div></td>
        </tr>
        <tr>
          <td height="53"><div align="center">
            <h2><em><strong>Derniére ligne de la D.A.I?</strong></em></h2>
          </div></td>
          <td colspan="2"><p>
            <label>
              <input type="radio" name="dld" value="o" id="Groupe de boutons radio1_0" />
              <strong><em>OUI</em></strong></label>
            <strong><em><br />
            <label>
              <input type="radio" name="dld" value="n" id="Groupe de boutons radio1_1" />
              NON</label>
            </em></strong>
            <br />
          </p></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2"><div align="right">
            <input name="ok" type="submit" class="Style19" id="ok" value="   Créer   " />
          </div></td>
          <td><div align="right" id="an">
            <div align="center">
              <input name="button" type="reset" class="Style19" id="button" value="Annuler" />
            </div>
          </div></td>
        </tr>
      </table>        
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
<script type="text/javascript">
<?php 
$ndai=$_POST['nd'];
$dat=$_POST['dd'];
$ca=$_POST['ca'];
$qd=$_POST['qd'];
$cu=$_POST['cu'];
$j=$_POST['jour'];
$m=$_POST['mois'];
$a=$_POST['anne'];
$num=$_POST['num'];
$date=$a."-".$m."-".$j;
$sql="INSERT INTO article VALUES ('','$ca','','','$ndai','','','','$qd','$cu','','$dat','$date')";
$r=mysql_query ($sql);
IF (!$r) {
   die('Requête invalide : ' . mysql_error());
}
 ?>
 </script>
