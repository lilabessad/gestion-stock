<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>chef de service</title>
<style type="text/css">
<!--
.Style15 {color: #2A00FF; font-style: italic; font-weight: bold; }
.Style11 {color: #FF7F00;
	font-style: italic;
	font-weight: bold;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body onload="MM_preloadImages('../rahma/fv.jpg')">
<form id="form1" name="form1" method="post" action="">
  <table width="1221" height="397" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1452" height="373"><table width="1176" height="330" border="0">
        <tr>
          <td height="72" colspan="3"><table width="267" height="67" border="3" bordercolor="#0000FF">
            <tr>
              <td width="81" rowspan="2"><img src="../rahma/fv.jpg" alt="CHEF" width="77" height="56" /></td>
              <td width="166" height="32"><span class="Style11">GESTIONNAIRE:</span></td>
            </tr>
            <tr>
              <td height="23">&nbsp;</td>
            </tr>
          </table></td>
          </tr>
        <tr>
          <td height="38" colspan="3" bgcolor="#0000FF"><h1 align="center"><span class="Style11">Bienvenue dans votre espace:</span></h1></td>
          </tr>
        <tr>
          <td width="29" height="31" rowspan="5" align="center">&nbsp;</td>
          <td width="769" height="44" align="center"><ul>
            <li>
              <h3 align="left" class="Style15"><a href="sign dai.php">CREATION D'UNE DEMANDE D'ACHAT INTERNE (D.A.I)</a></h3>
            </li>
          </ul></td>
          <td width="364" align="center">&nbsp;</td>
        </tr>
        <tr>
          <td height="37" align="center"><ul>
            <li>
              <h3 align="left" class="Style15">MODIFICATION D'UNE DEMANDE D'ACHAT INTERNE (D.A.I)</h3>
            </li>
          </ul></td>
          <td align="center">&nbsp;</td>
        </tr>
        <tr>
          <td height="38" align="center"><div align="left" class="Style15"><a href="../../../../../wamp/www/application/situation.php"></a>
            <ul>
              <li>SUPPRESSION D'UNE DEMANDE D'ACHAT INTERNE (D.A.I)</li>
            </ul>
          </div></td>
          <td height="38" align="center">&nbsp;</td>
        </tr>
        <tr>
          <td height="40" align="center"><div align="left" class="Style15">
            <ul>
              <li>GESTION DES SORTIE VERS LES UNITES DE PRODUCTION </li>
            </ul>
          </div></td>
          <td height="40" align="center">&nbsp;</td>
        </tr>
        <tr>
          <td height="45" align="center"><div align="left" class="Style15">
            <ul>
              <li>SAISIR L'INVENTAIRE</li>
            </ul>
          </div></td>
          <td height="45" align="center">&nbsp;</td>
        </tr>
        
        
        
        
      </table>      
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
