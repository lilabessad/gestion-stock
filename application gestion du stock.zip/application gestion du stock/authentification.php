<?php include('connection.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>authentification</title>
<script type="text/javascript">

function valider(){
 
 if(document.form1.nom.value == ""  && document.form1.mdp.value == ""){
   alert("Veuillez remplir ce formulaire!");
    document.form1.nom.focus();
   return false;
  }
 if(document.form1.nom.value == "") {
   alert("Veuillez entrer votre nom!");
   document.form1.nom.focus();
   return false;
  }
   if(document.form1.prenom.value == "") {
   alert("Veuillez entrer votre prenom!");
   document.form1.prenom.focus();
   return false;
  }
 if(document.form1.mdp.value == "") {
   alert("Veuillez entrer votre mot de passe!");
   document.form1.mdp.focus();
   return false;
  }
  }
  
</script>


<style type="text/css">

.Style2 {
	font-size: 24px;
	font-weight: bold;
}
body {
	
	margin-left: 20;
	margin-right: 30px;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Georgia, Times New Roman, Times, serif;
}
body,td,th {
	font-size: large;
}
.Style10 {font-size: 24px; font-weight: bold; color: #000000; }
.Style12 {
	color: #0000FF;
	font-style: italic;
	font-weight: bold;
	font-size: 36px;
}
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="Chef du service.php" onsubmit="return valider()">

  <table width="978" height="488" border="0" align="center" bgcolor="#AADFFF"> 
    <tr>
      <th height="484"><p>&nbsp;</p>
        <p>&nbsp;</p>
        <h6 align="center"><span class="Style12">Veuillez saisir votre nom et mot de passe:</span></h6>
        <p>&nbsp;</p>
        <table width="741" height="250" border="0" align="center" bordercolor="#F0F0F0">
        <tr>
          <th width="189" scope="row"><div align="right"><span class="Style10">Nom:</span></div></th>
          <td width="542"><label>
            <input name="nom" type="text" id="nom" size="50" maxlength="100" />
          </label></td>
        </tr>
        <tr>
          <th class="Style10" scope="row"><div align="right">Prénom:</div></th>
          <td><input name="prenom" type="text" id="prenom" size="50" maxlength="100" /></td>
        </tr>
        <tr>
          <th class="Style10" scope="row"><div align="right">Mot de passe:</div></th>
          <td><input name="mdp" type="password" id="mdp" size="50" maxlength="100" /></td>
        </tr>
      </table>
        <table width="290" border="0" align="right">
        <tr>
          <td width="134" height="45"><input name="submit" type="submit" class="Style10" id="ok" value="     OK      " /></td>
          <td width="146" valign="top"><label>
            <div align="center">
              <p>
                <input name="annuler" type="reset" class="Style10" id="annuler" value="Annuler" />
                </p>
            </div>
            <div align="center"></div>
          </label></td>
        </tr>
      </table>
      <p>
        <label></label>
      </p></th>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
<script type="text/javascript">
<?php
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$mdp=$_POST['mdp'];
if(isset ($_POST['submit'])){
$sql="SELECT modpas FROM authentification WHERE nom='$num' and prenom='$prenom'";
$rep=mysql_query($sql);
IF (!$rep) {
   die('Requête invalide : ' . mysql_error());
}
 if ($rep!=$mdp) {
echo'Désolé vous ne faites pas partie de ce systeme!';}}
?>
</script>












