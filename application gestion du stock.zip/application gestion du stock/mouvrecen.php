<?php session_start();include ('conec.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans nom</title>
<style type="text/css">
<!--
.Style1 {
	font-size: 36px;
	color: #990000;
}
.Style9 {
	font-size: 24px;
	color: #006400;
	font-weight: bold;
}
.Style10 {	color: #FF0000;
	font-size: 18px;
}
.Style3 {color: #000000}
.Style13 {font-size: 18px}
-->
</style>
</head>

<body>
<?php
if(isset($_POST['valid'])){
$nm = $_POST['numvm'];
$res = mysql_query("select * from mouvmenrecep where num_mv = ".$nm);
$az = mysql_query("select * from mouvmenrecep where num_mv = ".$nm);
$aze = mysql_query("select * from mouvmenrecep where num_mv = ".$nm);
$azer = mysql_query("select * from mouvmenrecep where num_mv = ".$nm);
$azert = mysql_query("select * from mouvmenrecep where num_mv = ".$nm);
$azerty = mysql_query("select * from mouvmenrecep where num_mv = ".$nm);
}
?>
<form id="form1" name="form1" method="post" action="mouvrecen.php" onsubmit=" return valider(); ">
  <table width="950" height="578" border="6" align="center" bordercolor="#CC00FF" bgcolor="#FFFFFF">
    <tr>
      <td height="562"><table width="961" height="560" border="0" align="center" b bgcolor="#FFFFFF">
        <tr>
          <td width="949" height="10" bgcolor="#FF99FF"><div align="center" class="Style1">Mouvement de r&eacute;ception </div></td>
        </tr>
        <tr>
          <td height="40"><table width="968" height="36" border="0">
            <tr>
              <td width="524" height="28"><span class="Style10">Veuillez saisissez le num&eacute;ro du mouvement que vous voulez afficher : </span></td>
              <td width="426"><p><span class="Style3">Num&eacute;ro de mouvement</span>
                    <label>
                    <input name="numvm" type="text" id="numvm" />
                    </label>
                    <input name="valid" type="submit" id="valid" value="Valider" />
              </p>
                </td>
            </tr>
          </table></td>
        </tr>
			
        <tr>
          <td height="30"><span class="Style9">Voici les informations cocernant se mouvement : </span></td>
        </tr>
        <tr>
          <td height="61"><table width="967" height="57" border="2">
              <tr>
                <td width="148" height="24"><div align="center" class="Style13">code article </div></td>
                <td width="214"><div align="center" class="Style13">designation</div></td>
                <td width="172"><div align="center" class="Style13">unit&eacute; de m&eacute;sure </div></td>
                <td width="181"><div align="center" class="Style13">quantit&eacute; manquante </div></td>
                <td width="216"><div align="center" class="Style13">quantit&eacute; en plus </div></td>
              </tr>
			   <?php 
if(isset($_POST['valid'])){
			?> 
			 <?php
  while($data=mysql_fetch_array ($res))
  {
  ?>
               <tr>
                <td height="23"><?php echo $data['cod_artc'];?>&nbsp;</td>
                <td><?php echo $data['des_artc'];?>&nbsp;</td>
                <td><?php echo $data['unit_mesu'];?>&nbsp;</td>
                <td><?php echo $data['qtit_manq'];?>&nbsp;</td>
                <td><?php echo $data['qtit_plus'];?>&nbsp;</td>
              </tr>
              <?php } ?>
			  <?php } ?>
          </table></td>
        </tr>
        <tr>
          <td height="49"><table width="946" height="26" border="0">
              <tr>
             <td width="193" height="22"><span class="Style13">nature de mouvement : </span></td>
				 <?php 
if(isset($_POST['valid'])){
			?> 
			 <?php
  while($data=mysql_fetch_array ($az))
  {
  ?>
                <td width="743"><?php echo $data['nat_mv'];?>&nbsp;</td>
              </tr>
          <?php } ?>
			  <?php } ?>
            </table>
              <label></label></td>
        </tr>
        <tr>
          <td height="49"><table width="949" height="26" border="0">
              <tr>
                <td width="194" height="22"><span class="Style13">Num&eacute;ro livraison
                    <label></label> 
                  : </span></td>
                <?php 
if(isset($_POST['valid'])){
			?> 
			 <?php
  while($data=mysql_fetch_array ($aze))
  {
  ?>
                <td width="745"><?php echo $data['num_liv'];?>&nbsp;</td>
              </tr>
             <?php } ?>
			  <?php } ?>
            </table>
            <label></label></td>
        </tr>
        <tr>
          <td height="49"><table width="958" height="26" border="0">
              <tr>
                <td width="195" height="22"><span class="Style13">Date de mouvement
                    <label></label> 
                  : </span></td>
                 <?php 
if(isset($_POST['valid'])){
			?> 
			 <?php
  while($data=mysql_fetch_array ($azer))
  {
  ?>
                <td width="753"><?php echo $data['dat_mv'];?>&nbsp;</td>
              </tr>
           <?php } ?>
			  <?php } ?>
            </table>
            <label></label></td>
        </tr>
        <tr>
          <td height="49"><table width="957" height="26" border="0">
              <tr>
                <td width="194" height="22"><span class="Style13">Service &eacute;metteur
                    <label> : </label>
                </span>                  <span class="Style13">
                <label></label>
                </span>                <label></label></td>
                       <?php 
if(isset($_POST['valid'])){
			?> 
			 <?php
  while($data=mysql_fetch_array ($azert))
  {
  ?>
                <td width="753"><?php echo $data['ser_emt'];?>&nbsp;</td>
              </tr>
             <?php } ?>
			  <?php } ?>
            </table>
            <label></label></td>
        </tr>
        <tr>
          <td height="49"><table width="955" height="26" border="0">
              <tr>
                <td width="190" height="22"><span class="Style13">Num&eacute;ro de mouvement : </span></td>
                <?php 
if(isset($_POST['valid'])){
			?> 
			 <?php
  while($data=mysql_fetch_array ($azerty))
  {
  ?>
                <td width="755"><?php echo $data['num_mv'];?>&nbsp;</td>
              </tr>
  <?php } ?>
			  <?php } ?>
            </table>
              <label></label></td>
        </tr>
		 <tr>
          <td height="113"><table width="945" height="30" border="0">
              <tr>
                <td width="276" height="26">&nbsp;</td>
                <td width="97"><label>
                  <input type="submit" name="Submit" value="Imprimer" />
                </label></td>
                <td width="558"><input type="submit" name="Submit2" value="Envoyer au chef de service" /></td>
              </tr>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
