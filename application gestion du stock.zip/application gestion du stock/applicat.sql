-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Client: 127.0.0.1
-- Généré le : Sam 31 Mai 2014 à 23:32
-- Version du serveur: 5.5.20
-- Version de PHP: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `application`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id_art` int(25) NOT NULL AUTO_INCREMENT,
  `code_art` varchar(15) NOT NULL,
  `des_art` varchar(15) NOT NULL,
  `unit_mesur` varchar(10) NOT NULL,
  `numdai` int(10) NOT NULL,
  `nummouv` int(10) NOT NULL,
  `numliv` int(10) NOT NULL,
  `numsor` int(10) NOT NULL,
  `qddai` int(10) NOT NULL,
  `cudai` varchar(5) NOT NULL,
  `qmouvement` int(10) NOT NULL,
  `dadedai` date NOT NULL,
  `dadart` date NOT NULL,
  `num_br` int(10) NOT NULL,
  PRIMARY KEY (`id_art`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Contenu de la table `article`
--

INSERT INTO `article` (`id_art`, `code_art`, `des_art`, `unit_mesur`, `numdai`, `nummouv`, `numliv`, `numsor`, `qddai`, `cudai`, `qmouvement`, `dadedai`, `dadart`, `num_br`) VALUES
(1, '100200', 'Tole_Inox', 'KG\r\n', 0, 10, 12, 0, 0, '', 27, '0000-00-00', '0000-00-00', 0),
(2, '100 212', 'Fil d''acier  4', 'KG\r\n', 0, 112, 0, 0, 0, '', 214, '0000-00-00', '0000-00-00', 0),
(3, '100 243', 'Fritte  M 339', 'KG\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(4, '100 250', 'Bande de cercla', 'ML\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(5, '100 309', 'Tôle LAF 0,6 X ', 'KG\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(6, '100 402', 'Fil Electrique ', 'ML\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(7, '100449A', 'Tôle décarb 0,6', 'KG\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(8, '100 628', 'Argile T', 'KG\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(9, '130 086', 'Tôle inox 0,7X9', 'KG\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(10, '201 058', 'Cosse faston', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(11, '201074A', 'Languette ', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(12, '201 075', 'Ressort bulbe', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(13, '201 080', 'Générateur 4 Fe', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(14, '201 081', 'Générateur 5 Fe', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(15, '201092A', 'Laine de verre', 'PCE\r\n\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(16, '201 102', 'Sachet ', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(17, '201 114', 'Profil gauche', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(18, '201 149', 'Vis  TCB M4X25 ', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(19, '201 155', 'Vis  TCB M5X8', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(20, '201 162', 'Vis TCB 4,2X32 ', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(21, '201 171', 'Vis TF Mx12  ', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(22, '201 173', 'Ecrou HM4 ', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(23, '201 175', 'Ecrou à ogive  ', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(24, '201 188', 'Plaque double', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(25, '201 189', 'Plaque double', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(26, '201 191', 'Rivet', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(27, '201 194', 'Rondelle ', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(28, '201 203', 'Bouchon rampe', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(29, '201 204', 'Tetine GB', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(30, '201239A', 'Robinet thermos', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(31, '230 138', 'Bougie d''alluma', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(32, '230 170', 'Contacteur d''al', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(33, '230 184', 'Injecteur G.B 0', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(34, '230 223', 'Robinet auxilia', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(35, '230 301', 'Manette gaz  65', 'PCE\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(36, '301 147', 'Sulfate de nick', 'KG\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(37, '301 157', 'Degraissant', 'KG\r\n\r\n', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(38, '', '', '', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(39, '12', '', '', 10, 0, 0, 0, 15, '', 0, '0000-00-00', '0000-00-00', 0),
(40, '', '', '', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(41, '', '', '', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(42, '', '', '', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0),
(43, '', '', '', 0, 0, 0, 0, 0, '', 0, '0000-00-00', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Structure de la table `authentification`
--

CREATE TABLE IF NOT EXISTS `authentification` (
  `nom` varchar(25) NOT NULL,
  `prenom` varchar(25) NOT NULL,
  `modpas` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `authentification`
--

INSERT INTO `authentification` (`nom`, `prenom`, `modpas`) VALUES
('kasdi', 'lydia', 'ali');

-- --------------------------------------------------------

--
-- Structure de la table `bultinr`
--

CREATE TABLE IF NOT EXISTS `bultinr` (
  `id_br` int(2) NOT NULL,
  `num_br` int(10) NOT NULL,
  `date_br` date NOT NULL,
  `numliv` int(10) NOT NULL,
  `four_br` varchar(25) NOT NULL,
  `emet_br` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bultinr`
--

INSERT INTO `bultinr` (`id_br`, `num_br`, `date_br`, `numliv`, `four_br`, `emet_br`) VALUES
(1, 1, '2014-05-06', 10, 'araour', 'alilouche');

-- --------------------------------------------------------

--
-- Structure de la table `dai`
--

CREATE TABLE IF NOT EXISTS `dai` (
  `id_dai` int(2) NOT NULL AUTO_INCREMENT,
  `numdai` int(5) NOT NULL,
  `origine` varchar(20) NOT NULL,
  `demission` date NOT NULL,
  `statut` varchar(20) NOT NULL,
  `objet` varchar(20) NOT NULL,
  `signature` varchar(15) NOT NULL,
  PRIMARY KEY (`id_dai`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Contenu de la table `dai`
--

INSERT INTO `dai` (`id_dai`, `numdai`, `origine`, `demission`, `statut`, `objet`, `signature`) VALUES
(1, 12, 'dhfyu', '2014-05-06', 'hccb ', 'ryghu', 'signÃ©e'),
(8, 0, '', '0000-00-00', '', '', 'signÃ©e'),
(9, 0, '', '0000-00-00', '', '', 'signÃ©e'),
(10, 0, 'on', '2013-11-19', 'Achat ferme', 'Achat conjucturel', 'signÃ©e'),
(11, 0, '', '0000-00-00', '', '', 'signÃ©e'),
(12, 0, 'on', '2013-02-14', 'Achat ferme', 'Achat conjucturel', 'signÃ©e'),
(13, 0, '', '0000-00-00', '', '', 'signÃ©e'),
(14, 0, '', '0000-00-00', '', '', 'signÃ©e'),
(15, 0, '', '0000-00-00', '', '', 'signÃ©e'),
(16, 0, 'on', '2012-09-29', 'Achat ferme', 'Achat conjucturel', 'signÃ©e'),
(17, 0, '', '0000-00-00', '', '', 'signÃ©e'),
(18, 0, 'on', '2014-11-18', 'Achat ferme', 'P.G.A', 'signÃ©e'),
(19, 0, '', '0000-00-00', '', '', 'signÃ©e'),
(20, 22, 'on', '2014-10-16', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e'),
(21, 0, '', '0000-00-00', '', '', 'signÃ©e'),
(22, 0, '', '0000-00-00', '', '', 'signÃ©e'),
(23, 0, 'on', '2013-11-18', 'Achat ferme', 'Achat conjucturel', 'signÃ©e'),
(24, 0, '', '0000-00-00', '', '', 'pas signÃ©e'),
(25, 0, '', '0000-00-00', '', '', 'pas signÃ©e'),
(26, 0, '', '0000-00-00', '', '', 'pas signÃ©e'),
(27, 0, '', '0000-00-00', '', '', 'pas signÃ©e'),
(28, 0, 'on', '2002-03-03', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e'),
(29, 0, '', '0000-00-00', '', '', 'pas signÃ©e'),
(30, 0, 'on', '2002-02-02', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e'),
(31, 0, 'on', '2002-02-02', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e'),
(32, 0, 'on', '2002-02-02', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e'),
(33, 0, 'on', '2002-02-02', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e'),
(34, 0, 'on', '2002-02-02', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e'),
(35, 0, '', '0000-00-00', '', '', 'pas signÃ©e'),
(36, 0, 'on', '2014-11-18', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e'),
(37, 0, 'on', '2014-11-18', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e'),
(38, 0, '', '0000-00-00', '', '', 'pas signÃ©e'),
(39, 0, 'on', '2004-04-02', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e'),
(40, 0, 'on', '2004-04-02', 'Achat ferme', 'Achat conjucturel', 'pas signÃ©e');

-- --------------------------------------------------------

--
-- Structure de la table `livraison`
--

CREATE TABLE IF NOT EXISTS `livraison` (
  `id_liv` int(2) NOT NULL AUTO_INCREMENT,
  `numliv` int(10) NOT NULL,
  `dlivraison` date NOT NULL,
  `etat_recep` int(25) NOT NULL,
  PRIMARY KEY (`id_liv`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `mouvement`
--

CREATE TABLE IF NOT EXISTS `mouvement` (
  `id_m` int(2) NOT NULL AUTO_INCREMENT,
  `nummouv` int(10) NOT NULL,
  `numliv` int(15) NOT NULL,
  `naturmouv` varchar(25) NOT NULL,
  `dmouvement` date NOT NULL,
  `service` varchar(25) NOT NULL,
  `signature` varchar(25) NOT NULL,
  PRIMARY KEY (`id_m`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `mouvement`
--

INSERT INTO `mouvement` (`id_m`, `nummouv`, `numliv`, `naturmouv`, `dmouvement`, `service`, `signature`) VALUES
(1, 10, 12, 'excedent reception', '2014-05-21', 'GSCU', 'signÃ©'),
(2, 112, 145, 'excedent', '2014-05-06', 'GSCU', 'signÃ©');

-- --------------------------------------------------------

--
-- Structure de la table `sortiem`
--

CREATE TABLE IF NOT EXISTS `sortiem` (
  `id_s` int(11) NOT NULL AUTO_INCREMENT,
  `numsor` int(11) NOT NULL,
  `dsortie` date NOT NULL,
  PRIMARY KEY (`id_s`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
