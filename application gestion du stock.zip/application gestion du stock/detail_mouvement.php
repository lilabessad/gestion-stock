<?php include('connection.php');
$v= $_GET['num'];
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Document sans titre</title>
<script type="text/javascript">
function valider(){
 
 if(document.form1.sign.value =="signé") {
   alert("Ce mouvement de reception est deja signé!");
   return false;
  }
  }
  </script>
  
<style type="text/css">
<!--
.Style1 {
	color: #FFFF00;
	font-weight: bold;
}
.Style2 {
	color: #FF0000;
	font-weight: bold;
}
-->
</style>
<script type="text/javascript">
function edition()
    {
    options = "Width=700,Height=700" ;
    window.open( "edition.php", "edition", options ) ;
    }
	
	</script>
</head>

<body>
<?php
$sql1= "select nummouv,numliv,naturmouv,dmouvement,service,signature from mouvement where nummouv='$v'" ;
$r1=mysql_query ($sql1);
IF (!$r1) {
   die('Requête invalide : ' . mysql_error());
}
$sql2= "select code_art,des_art,unit_mesur,qmouvement from article where nummouv='$v'" ;
$r2=mysql_query ($sql2);
IF (!$r2) {
   die('Requête invalide : ' . mysql_error());
}


?>
<form id="form1" name="form1" method="post" action="" onsubmit="return valider();">
  <table width="1194" height="439" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1166" height="415"><table width="1165" height="374" border="0" align="center">
                <?php
  while( $data2=mysql_fetch_array ($r1))
  {
  ?>
        <tr>
          <td height="18" colspan="4"><div align="center">
            <h3 align="left"><a href="edition.php" onclick="edition();return false;"><img src="images/lkj.png" alt="im" width="29" height="24" />EDITER </a></h3>
          </div></td>
        </tr>
        <tr>
          <td height="18" colspan="4" bgcolor="#0000FF"><div align="center">
            <h1><span class="Style1">mouvement de reception</span></h1>
          </div></td>
        </tr>
        <tr>
          <td height="38"><div align="right"><strong>Service emetteur du mouvement:</strong></div></td>
          <td height="38"><input type="text" name="se" id="se" value="<?php echo $data2['service'];?>" /></td>
          <td height="38"><div align="right"><strong>Date du mouvement:</strong></div></td>
          <td width="206"><input name="dm" type="text" id="dm" value="<?php echo $data2['dmouvement'];?>" size="25" /></td>
        </tr>
        <tr>
          <td width="238" height="42"><div align="right"></div></td>
          <td width="302"><div align="right">
            <h3><strong>Nature du mouvement:</strong></h3>
          </div></td>
          <td width="401"><input name="natur" type="text" class="Style2" id="natur" value="<?php echo $data2['naturmouv'];?>" size="50" /></td>
          <td height="42">&nbsp;</td>
        </tr>
        <tr>
          <td height="17"><div align="right"><strong>Numéro du mouvement:</strong></div></td>
          <td height="17"><h2>
            <input type="text" name="nm" id="nm" value="<?php echo $data2['nummouv'];?>" />
          </h2></td>
          <td height="17"><div align="right"><strong>Numéro de livraison:</strong></div></td>
          <td height="17"><input type="text" name="nl" id="nl" value="<?php echo $data2['numliv'];?>" /></td>
        </tr>
        <tr>
          <td height="59"><p>&nbsp;</p>
            <p align="right"><a href="edition.php" onclick="edition();return false;"></a>
              <label></label>
            </p></td>
          <td height="59"><div align="right">
            <h3>Signature:</h3>
          </div></td>
          <td height="59"><label>
            <input type="text" name="sign" id="sign"  value="<?php echo $data2['signature'];?>" />
          </label></td>
          <td height="59">&nbsp;</td>
        </tr>
        <tr>
          <td height="56" colspan="4"><div align="right">
            <table width="1129" height="90" border="0" align="center">
              <tr>
                <td colspan="4" bgcolor="#A0A0A4"><div align="center">
                    <h3><strong>ARTICLE</strong></h3>
                </div></td>
              </tr>
              <tr>
                <td width="75" bgcolor="#FFCCFF"><div align="center"><strong>CODE</strong></div></td>
                <td width="290" bgcolor="#FFCCFF"><div align="center"><strong>DESIGNATION</strong></div></td>
                <td width="65" bgcolor="#FFCCFF"><div align="center"><strong>UNITE</strong></div></td>
                <td width="239" bgcolor="#FFCCFF"><div align="center"><strong>QUANTITE DU MOUVEMENT</strong></div></td>
              </tr>
              <?php
  while( $data=mysql_fetch_array ($r2))
  {
  ?>
              <tr>
                <td height="21" bgcolor="#FFFBF0"><?php echo $data['code_art'];?>&nbsp;</td>
                <td bgcolor="#FFFBF0"><?php echo $data['des_art'];?>&nbsp;</td>
                <td bgcolor="#FFFBF0"><?php echo $data['unit_mesur'];?>&nbsp;</td>
                <td bgcolor="#FFFBF0"><?php echo $data['qmouvement'];?>&nbsp;</td>
              </tr>
              <?php } ?>
            </table>
            <label>
            <input type="reset" name="annuler" id="annuler" value="Annuler"/>
            </label>
            <?php
$sql="UPDATE mouvement SET signature ='signé' WHERE nummouv='$v'";
$rep=mysql_query($sql);
IF (!$rep) {
   die('Requête invalide : ' . mysql_error());
}?>
            <input type="submit" name="si" id="si" value="Signer" />
          </div></td>
        </tr>
         <?php } ?>
      </table>
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
