<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>application sur gestion de stock</title>
<link rel="stylesheet" href="css/style.css"/>
<script type="text/javascript">
//<![CDATA[

function valider(){
// si la valeur du champ prenom est non vide
if(document.form1.jour.value !="jour" && document.form1.mois.value !="Mois" && document.form1.anne.value !="Ann�e" && document.form1.odai.value !="" && document.form1.odai.value !="" && document.form1.statut[0].checked!=false || document.form1.statut[1].checked!=false && (document.form1.stat[0].checked!=false || document.form1.stat[1].checked!=false || document.form1.stat[2].checked!=false) ) {
// les donn�es sont ok, on peut envoyer le formulaire 
return true;
}
else {
// sinon on affiche un message
alert("Veuillez saisir toutes les informations necessaires pour votre D.A.I");
// et on indique de ne pas envoyer le formulaire
return false;
}

}

<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body onload="MM_preloadImages('images/dy.jpg')">
<form id="form1" name="form1" method="post" action="">
<table width="950" height="664" border="4" cellpadding="2" align="center" bordercolor="#999999" background="images/blue.jpg">
<tr>
<th height="118" scope="col"><table width="482" height="112" border="0" align="left" cellpadding="2">
  <tr>
    <td width="272" height="49">&nbsp;</td>
  </tr>
  <tr>
    <td height="27"><a href="gestionnaire.php"><img src="images/fe.png" width="72" height="37" border="0" /></a></td>
  </tr>
</table>
<table width="290" height="112" border="0" align="right" cellpadding="2">
<tr>
<th width="74" scope="col">&nbsp;</th>
<th width="145" height="39" scope="col"> <span class="Style1"> Gestionnaire </span></th>
<th width="72" rowspan="2" scope="col"><img src="images/logoEniem.jpg" width="82" height="100" /></th>
</tr>
<tr>
<th width="74" scope="col"><img src="images/azeeezere.jpg" width="58" height="63" /></th>
<th height="67" scope="col"><label></label>
<a href="essai.php">Deconnecter</a><img src="images/vrg.jpg" width="31" height="30" /></th>
</tr>
</table></th>
</tr>
<tr>
<td height="402" valign="top"><div align="center">
  <table width="889" height="464" cellpadding="2">
    <tr>
      <th colspan="2" scope="col" ><p><span class="Style2"> Modidfication d'une D.A.I(Demande d'Achat Interne) </span></p>
          <p align="right"> <span class="Style3">Affection :gestion de stock de l'unite cuisson(ENIEM) </p></th>
    </tr>
    <tr>
      <th width="258" scope="row"><span class="Style1">Agent: </span></th>
      <td width="300"><label>
        <input type="text" name="textfield2" />
      </label></td>
    </tr>
    <tr>
      <th height="25" colspan="2" scope="row"><p>
          <label></label>
        Veuillez choisir l'une des operations suivantes: <br />
      </p></th>
    </tr>
    <tr>
      <th height="99" scope="row"><label>
          <div align="left">
            <input type="radio" name="Groupe de boutons radio1" value="bouton radio" /><span class="Style1">
            Modifier l'entete de D.A.I </span></div>
        </label>
        <label>
          <div align="left">
            <input type="radio" name="Groupe de boutons radio1" value="bouton radio" /><span class="Style1">
            Modifier une ligne d'une D.A.I </span></div>
        </label>
        <label></label>
        <label>
          <div align="left">
            <input type="radio" name="Groupe de boutons radio1" value="bouton radio" /><span class="Style1">
            Supprimer des lignes d'une D.A.I </span></div>
        </label>
        <label></label></th>
      <th scope="row"><div align="left">
          <input type="radio" name="Groupe de boutons radio1" value="bouton radio" /><span class="Style1">
        Ajouter une ou plusieurs ligne </span></div>
          <div align="left">
            <input type="radio" name="Groupe de boutons radio1" value="bouton radio" /><span class="Style1">
            Consulter une D.A.I </span></div></th>
    </tr>
    <tr>
      <th colspan="2" scope="row">Veuillez d'abord saisir ces informations pour effectuer votre operation: </th>
    </tr>
    <tr>
      <th scope="row"><p>
          <label></label>
          <label></label>
          <label></label><span class="Style1">
        Numero de la D.A.I : </span></p></th>
      <th scope="row"><label>
        <input type="text" name="textfield3" />
      </label></th>
    </tr>
    <tr>
      <th scope="row"><span class="Style1">code de l'article: </span></th>
      <th scope="row"><label>
        <input type="text" name="textfield4" />
      </label></th>
    </tr>
    <tr>
      <th scope="row"><span class="Style1">suivi de D.A.I : </span></th>
      <th scope="row"><label>
        <input type="text" name="textfield5" />
      </label></th>
    </tr>
    <tr>
      <th height="49" scope="row">&nbsp;</th>
      <td><label>
          <div align="center">
            <input type="submit" name="Submit" class="Style6" value="  Creer   " />
            <input type="submit" name="Submit2"  class="Style6" value="Annuler" />
          </div>
        </label></td>
    </tr>
  </table>
  </div>
<tr>
  <td height="60" bgcolor="#C0C0C0"><?php
		include('header.php'); 
		include('footer.php');

	?></td>
  </table>
<p>&nbsp;</p>
<p>&nbsp;</p>
</form>
</body>
</html>


