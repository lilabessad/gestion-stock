<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>suppression d'une dai</title>
<script type="text/javascript">
//<![CDATA[

function assure(){
  // si la valeur de la dai ni pas saisir
  if(document.form1.nd.value !="" )
        {
		alert ("voulez vous vraiment supprimer cette D.A.I ??");
    // les données sont ok, on peut envoyer le formulaire    
    return true;
  }
  else {
    // sinon on affiche un message
    alert("Veuillez saisir toutes les informations necessaires pour votre D.A.I");
    // et on indique de ne pas envoyer le formulaire
    return false;
  }
  
}

//]]>
</script>

<style type="text/css">
<!--
.Style1 {
	color: #FFDF00;
	font-weight: bold;
	font-style: italic;
}
.Style16 {
	color: #0000FF;
	font-style: italic;
	font-weight: bold;
	font-size: 9mm;
}
.Style10 {color: #2A0055}
.Style9 {color: #2A0055;
	font-style: italic;
	font-weight: bold;
}
.Style18 {
	color: #0000FF;
	font-weight: bold;
	font-style: italic;
	font-size: 36px;
}
.Style19 {color: #0000FF; font-weight: bold; font-style: italic; font-size: 18px; }
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="" onsubmit="return assure();">
  <table width="1271" height="472" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1264" height="448"><table width="1247" height="413" border="0" align="center">
        <tr>
          <td height="62" colspan="4" bgcolor="#0000FF"><div align="center">
            <h1><span class="Style1">SUPPRESSION DE D.A.I:</span></h1>
          </div></td>
        </tr>
        <tr>
          <td width="153" height="145" valign="top"><em><strong>AGENT:</strong></em></td>
          <td width="389">&nbsp;</td>
          <td width="312">&nbsp;</td>
          <td width="371" valign="top"><div align="right">
            <h4><span class="Style9">AFFECTION</span><span class="Style10">:</span>G.S UNITE CUISSON (ENIEM)</h4>
          </div></td>
        </tr>
        <tr>
          <td height="92">Numéro de la D.A.I:</td>
          <td><input type="text" name="nd" id="nd" /></td>
          <td>Date d'emission de la D.A.I:</td>
          <td height="92"><label></label></td>
        </tr>
        <tr>
          <td height="51">Objet de la D.A.I:</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td height="51">&nbsp;</td>
        </tr>
        <tr>
          <td height="51" colspan="2">&nbsp;</td>
          <td height="51" valign="bottom"><div align="right">
            <input name="ok" type="submit" class="Style19" id="ok" value="Supprimer"/>
          </div></td>
          <td height="51" valign="bottom"><div align="right" id="an">
            <div align="center">
              <input name="button" type="reset" class="Style19" id="button" value="Annuler" />
            </div>
          </div></td>
        </tr>
      </table>      
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
