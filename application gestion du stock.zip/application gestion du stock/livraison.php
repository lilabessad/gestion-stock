<?php 
session_start();include('connection.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style16 {color: #FF5F00}
.Style17 {color: #FF7F00}
-->
</style>
</head>

<body>
<?php
$sql= 'select id_liv,numliv,dlivraison,etat_recep,etabli,modliv,fourliv from livraison';
$r=mysql_query ($sql);
IF (!$r) {
   die('Requête invalide : ' . mysql_error());
}

?>
<form id="form1" name="form1" method="post" action="">
  <table width="1221" height="191" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1452" height="167"><table width="1194" height="132" border="0" align="center">
        <tr>
          <td width="1184" height="56" colspan="2" bgcolor="#0000FF"><div align="center" class="Style16">
            <h2 class="Style17">LISTE DES LIVRAISONS</h2>
          </div></td>
        </tr>
        <tr>
          <td height="55" colspan="2"><table width="1201" height="48" border="0" align="center">
            <tr>
              <td width="36" height="21" bgcolor="#A0A0A4">N°</td>
              <td width="185" bgcolor="#A0A0A4">NUMERO DE LIVRAISON</td>
              <td width="170" bgcolor="#A0A0A4">DATE DE LIVRAISON</td>
              <td width="155" bgcolor="#A0A0A4">ETABLISSEMENT</td>
              <td bgcolor="#A0A0A4">MODE LE LIVRAISON</td>
              <td bgcolor="#A0A0A4"> FOURNISSEUR</td>
              <td colspan="2" bgcolor="#A0A0A4">ETAT RECEPTION</td>
            </tr>
            <?php
  while($data=mysql_fetch_array($r))
  {
  ?>
            <tr>
              <td height="21" bgcolor="#FFCCFF"><?php echo $data['id_liv'];?>&nbsp;</td>
              <td height="21" bgcolor="#FFFBF0"><?php echo $data['numliv'];?>&nbsp;</td>
              <td bgcolor="#FFFBF0"><?php echo $data['dlivraison'];?>&nbsp;</td>
              <td bgcolor="#FFFBF0"><?php echo $data['etabli'];?>&nbsp;</td>
              <td width="180" bgcolor="#FFFBF0"><?php echo $data['modliv'];?>&nbsp;</td>
              <td width="163" bgcolor="#FFFBF0"><?php echo $data ['fourliv']; ?>&nbsp;</td>                          
             <td width="157" bgcolor="#FFFBF0"><?php echo $data ['etat_recep']; ?>&nbsp;</td>             
              <td width="121" bgcolor="#FFCCFF"><a href="detailliv.php?numliv=<?php echo $data ['numliv']; ?>">VOIR DETAILS</a>                          </tr>
            <?php
			 }?>
          </table></td>
        </tr>
        
        
        
      </table>
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
