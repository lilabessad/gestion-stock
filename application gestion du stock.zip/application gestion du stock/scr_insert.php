<?php include('accebd.php'); 
$ma=$_POST['marque'];
$ty=$_POST['type'];
$an=$_POST['annee'];
$sql='insert into tableveh (marque_veh, type_veh, annee_veh, occup_veh) values("'.$ma.'","'.$ty.'","'.$an.'","non")';
mysql_query($sql);
include ('list_veh.php');
?>
