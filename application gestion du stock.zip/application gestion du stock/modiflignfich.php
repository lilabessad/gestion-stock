<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style9 {font-size: 18px; font-weight: bold; }
-->
</style>
</head>

<body>
<?php 
$v= $_GET['id'];
include ('conec.php');
$s= 'select * from fichconcerne where id_fich='.$v;
$res=mysql_query($s);
 while ($d=mysql_fetch_array($res))
 {
 ?>
<form id="form1" name="form1" method="post" action="scriptmodiflign.php">
  <table width="1067" height="104" border="2">
    <tr>
      <td width="148" rowspan="2"><span class="Style9">Identificateur fiche </span></td>
      <td height="23"  bgcolor="#FF99FF"colspan="2"><div align="center" class="Style9">Pi&egrave;ce comptable </div></td>
      <td colspan="3" bgcolor="#FF99FF"><div align="center" class="Style9">Quantit&eacute;</div></td>
    </tr>
    <tr>
      <td width="174" height="24"><div align="center" class="Style9">Date</div></td>
      <td width="190"><div align="center" class="Style9">Nature et r&eacute;f&eacute;rence </div></td>
      <td width="171"><div align="center" class="Style9">Entr&eacute;e</div></td>
      <td width="174"><div align="center" class="Style9">Sortie</div></td>
      <td width="168"><div align="center" class="Style9">Solde</div></td>
    </tr>
    <tr>
      <td height="44" align="center"><label></label>
      <div align="center"> <input name="id" type="hidden" value="<?php echo $d['id_fich'];?> " /></div></td>
      <td height="44" align="center"><div align="center">
        <input name="dat" type="text" id="dat"   value="<?php echo $d['dat_stcartc']; ?> "/>
      </div></td>
      <td align="center"><div align="center"><input name="natref" type="text" id="natref"  value="<?php echo $d['natt_stc']; ?>"/>
        </div>
      </label></td>
      <td align="center"><label>
        <input name="entr" type="text" id="entr" value="<?php echo $d['entr_stc']; ?>" />
      </label></td>
      <td align="center"><div align="center"><input name="sor" type="text" id="sor"  value="<?php echo $d['sort_stc']; ?>"/>
        </div>
      </label></td>
      <td align="center"><label>
        <input name="sold" type="text" id="sold" value="<?php echo $d['sold']; ?>" />
      </label></td>
    </tr>
  </table>
  <p>
    <label>
    <input name="envoy" type="submit" id="envoy" value="Envoyer" />
    </label>
  </p>
</form>
<?php
}
?>
</body>
</html>
