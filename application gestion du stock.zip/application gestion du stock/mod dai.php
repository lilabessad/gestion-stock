<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Document sans titre</title>
<script type="text/javascript">
//<![CDATA[

function valider(){
  // si la valeur du champ prenom est non vide
  if(document.form1.md.value !="" && document.form1.ca.value !="" && document.form1.suivid.value !="" && (document.form1.mdai[0].checked!=false || document.form1.mdai[1].checked!=false || document.form1.mdai[2].checked!=false || document.form1.mdai[3].checked!=false || document.form1.mdai[4].checked!=false) )        {
    // les données sont ok, on peut envoyer le formulaire    
    return true;
  }
  else {
    // sinon on affiche un message
    alert("Veuillez saisir toutes les informations necessaires pour votre D.A.I");
    // et on indique de ne pas envoyer le formulaire
    return false;
  }
  
}

//]]>
</script>
<style type="text/css">
<!--
.Style1 {
	color: #FFDF00;
	font-weight: bold;
	font-style: italic;
}
.Style6 {
	color: #FF1F00;
	font-style: italic;
	font-weight: bold;
}
.Style7 {color: #2A0000}
.Style12 {font-weight: bold; font-style: italic; color: #D40000; }
.Style15 {color: #2A00AA; font-style: italic; font-weight: bold; font-size: 10mm; }
.Style16 {
	color: #0000FF;
	font-style: italic;
	font-weight: bold;
	font-size: 9mm;
}
.Style10 {color: #2A0055}
.Style9 {	color: #2A0055;
	font-style: italic;
	font-weight: bold;
}
.Style19 {color: #0000FF; font-weight: bold; font-style: italic; font-size: 18px; }
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="" onsubmit="return valider();">
  <table width="1292" height="563" border="10" align="center" bordercolor="#FF5F00" bgcolor="#AADFFF">
    <tr>
      <td width="1264" height="539"><table width="1253" height="534" border="0" align="center">
        <tr>
          <td height="24" colspan="4" bgcolor="#0000FF"><div align="center">
            <h1 class="Style1">MODIFICATION DE D.A.I:</h1>
          </div></td>
        </tr>
        <tr>
          <td height="25" colspan="3"><em><strong>AGENT:</strong></em></td>
          <td height="25"><div align="right">
            <h4><span class="Style9">AFFECTION</span><span class="Style10">:</span>G.S UNITE CUISSON (ENIEM)</h4>
          </div></td>
        </tr>
        <tr>
          <td height="27" colspan="4" valign="top"><h2 class="Style12">Veuillez choisir l'une des opérations suivantes:</h2></td>
        </tr>
        <tr>
          <td height="252" colspan="4" align="left" valign="top"><p class="Style7">
            <label></label>
            </p>
            <table width="1243" height="212" border="0" align="left" bordercolor="#0000FF">
              
              <tr>
                <td width="385" align="left" valign="top"><h2>
                  <input name="mdai" type="radio" id="m dai_0" value="ennt" />
                  <em><strong><em><strong>Modifier l'entête d'une D.A.I</strong></em></strong></em></h2></td>
                <td width="392" height="61" align="left" valign="top"><h2><em><strong><em><strong>
                  <input type="radio" name="mdai" value="ligne" id="m dai_1" />
Modifier une ligne d'une D.A.I</strong></em></strong></em></h2></td>
                <td width="452" align="left" valign="top"><h2><em><strong><em><strong>
                  <input type="radio" name="mdai" value="ajou" id="m dai_2" />
                  Ajouter une ou plusieurs lignes</strong></em></strong></em></h2></td>
                </tr>
              
              <tr>
                <td height="145" colspan="3" align="left" valign="top"><table width="1054" height="98" border="0" align="center">
                  <tr>
                    <td width="503" height="94"><h2><em><strong>
<input type="radio" name="mdai" value="supp" id="m dai_3" /> 
Supprimer des lignes d'une D.A.I</strong></em></h2></td>
                    <td width="541"><h2><em><strong>
                      <input name="mdai" type="radio" id="m dai_4" value="list" />
                      Liste de lignes des D.A.I affectées à un article</strong></em></h2></td>
                  </tr>
                </table>                   </td>
              </tr>
            </table>
            <p class="Style7">
              <label></label>
              </p></td>
        </tr>
        <tr>
          <td height="30" colspan="4"><div align="center">
            <h2 align="left" class="Style6">Veuillez saisir les informations necessaires pour effectuer votre opération:</h2>
          </div></td>
        </tr>
        <tr>
          <td width="352"><div align="center">
            <h2><strong><em>Numéro de la D.A.I:</em></strong></h2>
          </div></td>
          <td colspan="3"><label>
            <input type="text" name="md" id="mn" />
          </label></td>
        </tr>
        <tr>
          <td height="42"><div align="center">
            <h2><strong><em>Code de l'article:</em></strong></h2>
          </div></td>
          <td colspan="3"><label>
            <input type="text" name="ca" id="mca" />
          </label></td>
        </tr>
        <tr>
          <td height="70" valign="top"><div align="center">
            <h2><strong><em>Suivi de la D.A.I:</em></strong></h2>
          </div></td>
          <td width="326" valign="top">
          <input name="suivid" type="text" id="suivid" value="" /></td>
          <td width="202" align="center" valign="bottom"><label>
            <div align="right">
              <div align="right">
                <input name="ok" type="submit" class="Style19" id="ok" value="Modifier" />
              </div>
              <br />
            </div>
          </label></td>
          <td width="355" align="center" valign="middle"><div align="right" id="an">
            <div align="center">
              <input name="button" type="reset" class="Style19" id="button" value="Annuler" />
            </div>
          </div></td>
        </tr>
      </table>
      <h6>&nbsp;</h6></td>
    </tr>
  </table>
</form>
</body>
</html>
