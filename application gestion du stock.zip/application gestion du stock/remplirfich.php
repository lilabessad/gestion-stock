<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style3 {font-size: 24px; color: #0000FF; }
.Style4 {	font-size: 36px;
	color: #FF0000;
	font-family: Arial, Helvetica, sans-serif;
}
.Style7 {font-size: 18px; color: #0000FF; font-weight: bold; font-family: Arial, Helvetica, sans-serif; }
.Style9 {font-size: 18px; font-weight: bold; }
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="scriptremplirfich.php">
  <table width="1083" height="539" border="6" align="center"  bordercolor="#99CCFF">
    <tr>
      <td width="1063" height="523"><table width="1058" height="520" border="0">
        <tr>
          <td height="36" colspan="3"  bgcolor="#99FFFF"><div align="center" class="Style4">Fiche de casier </div></td>
        </tr>
        <tr>
          <td height="32" colspan="3"><span class="Style3 Style2">Veuillez remplir les champs: </span></td>
        </tr>
        <tr>
          <td width="314" height="49"><table width="253" border="0">
            <tr>
              <td width="92"><span class="Style9">Unit&eacute; : </span></td>
              <td width="151"><label>
                <input name="unit" type="text" id="unit" />
              </label></td>
            </tr>
          </table></td>
          <td width="453"><table width="350" border="0">
            <tr>
              <td width="188"><span class="Style9">Num&eacute;ro de la fiche : </span></td>
              <td width="152"><label>
                <input name="numfich" type="text" id="numfich" />
              </label></td>
            </tr>
          </table></td>
          <td width="282"><table width="273" border="0">
            <tr>
              <td width="110"><span class="Style9">Etablie par : </span></td>
                          <td width="153"><label>
                <input name="etableur" type="text" id="etableur" />
              </label></td>
            </tr>
            </table></td>
        </tr>
        <tr>
          <td height="28"><table width="258" border="0">
            <tr>
              <td width="91"><span class="Style9">Structure : </span></td>
                           <td width="157"><label>
                <input name="struct" type="text" id="struct" />
              </label></td>
            </tr>
          </table></td>
          <td><table width="365" border="0">
            <tr>
              <td width="190"><span class="Style9">Date de l'&eacute;tablissement : </span></td>
              <td width="165"><label>
                <input name="datetabl" type="text" id="datetabl" />
              </label></td>
            </tr>
          </table></td>
          <td><table width="275" border="0">
            <tr>
              <td width="113" height="22"><span class="Style9">Sign&eacute;e par : </span></td>
              <td width="152"><label>
                <input name="signateur" type="text" id="signateur" />
              </label></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td height="55" colspan="3"><div align="center" class="Style7">Informations concernant l'article :</div></td>
        </tr>
        <tr>
          <td height="29" colspan="3"><table width="1056" height="57" border="2">
            <tr>
              <td width="144"><div align="center" class="Style9">Code article </div></td>
              <td width="144"><div align="center" class="Style9">D&eacute;signation article </div></td>
              <td width="144"><div align="center" class="Style9">Unit&eacute; de m&eacute;sur </div></td>
              <td width="144"><div align="center" class="Style9">Stock minimal </div></td>
              <td width="144"><div align="center" class="Style9">Magasin</div></td>
              <td width="144"><div align="center" class="Style9">Emplacement</div></td>
              <td width="144"><div align="center" class="Style9">Case(rayon)</div></td>
            </tr>
            <tr>
              <td align="center" height="23"><label>
                <input name="codartl" type="text" id="codartl" />
              </label></td>
              <td align="center"><label>
                <input name="desartl" type="text" id="desartl" />
              </label></td>
              <td align="center"><label>
                <input name="unimes" type="text" id="unimes" />
              </label></td>
              <td align="center"><label>
                <input name="stkmin" type="text" id="stkmin" />
              </label></td>
              <td align="center"><label>
                <input name="magasi" type="text" id="magasi" />
              </label></td>
              <td align="center"><label>
                <input name="emplac" type="text" id="emplac" />
              </label></td>
              <td align="center"><input name="cas" type="text" id="cas" /></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td height="44" colspan="3"><div align="center"><span class="Style7">Informations concernant le stockage de l'article: </span></div></td>
        </tr>
        <tr>
          <td height="106" colspan="3"><table width="1057" height="105" border="2">
            <tr>
              <td height="23" colspan="2"><div align="center" class="Style9">Pi&egrave;ce comptable </div></td>
              <td colspan="3"><div align="center" class="Style9">Quantit&eacute;</div></td>
            </tr>
            <tr>
              <td width="158" height="11"><div align="center" class="Style9">Date</div></td>
              <td width="241"><div align="center" class="Style9">Nature et r&eacute;f&eacute;rence </div></td>
              <td width="203"><div align="center" class="Style9">Entr&eacute;e</div></td>
              <td width="211"><div align="center" class="Style9">Sortie</div></td>
              <td width="207"><div align="center" class="Style9">Solde</div></td>
            </tr>
            <tr>
              <td align="center" height="23"><label>
                <input name="dat" type="text" id="dat" />
              </label></td>
              <td align="center"><label>
                <input name="natrefr" type="text" id="natrefr" />
              </label></td>
              <td align="center"><label>
                <input name="entre" type="text" id="entre" />
              </label></td>
              <td align="center"><label>
                <input name="sorti" type="text" id="sorti" />
              </label></td>
              <td align="center"><label>
                <input name="sold" type="text" id="sold" />
              </label></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td height="70" colspan="2"><label>
            <div align="right">
              <input name="valid" type="submit" id="valid" value="Valider" />
              </div>
          </label></td>
          <td height="70">&nbsp;</td>
        </tr>
      </table></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
</body>
</html>
